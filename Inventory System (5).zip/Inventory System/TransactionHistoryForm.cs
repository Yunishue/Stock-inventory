﻿using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class TransactionHistoryForm : Form
    {
        private DatabaseManager dbManager;
        private static readonly CultureInfo filipinoCulture = new CultureInfo("fil-PH");

        public TransactionHistoryForm(DatabaseManager dbManager)
        {
            InitializeComponent();
            this.dbManager = dbManager;
        }

        private void TransactionHistoryForm_Load(object sender, EventArgs e)
        {
            ThemeManager.ApplyTheme(this);
            dtpStartDate.Value = DateTime.Now.AddDays(-30);
            dtpEndDate.Value = DateTime.Now;
            LoadTransactions();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadTransactions();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dtpStartDate.Value = DateTime.Now.AddDays(-30);
            dtpEndDate.Value = DateTime.Now;
            LoadTransactions();
        }

        private void LoadTransactions()
        {
            try
            {
                DateTime startDate = dtpStartDate.Value.Date;
                DateTime endDate = dtpEndDate.Value.Date.AddDays(1).AddSeconds(-1);

                DataTable dt = dbManager.GetSalesTransactions(startDate, endDate);
                dgvTransactions.DataSource = dt;

                if (dgvTransactions.Columns.Contains("TotalAmount"))
                {
                    dgvTransactions.Columns["TotalAmount"].DefaultCellStyle.Format = "C2";
                    dgvTransactions.Columns["TotalAmount"].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvTransactions.Columns["TotalAmount"].HeaderText = "Total (PHP)";
                }
                if (dgvTransactions.Columns.Contains("AmountPaid"))
                {
                    dgvTransactions.Columns["AmountPaid"].DefaultCellStyle.Format = "C2";
                    dgvTransactions.Columns["AmountPaid"].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvTransactions.Columns["AmountPaid"].HeaderText = "Paid (PHP)";
                }
                if (dgvTransactions.Columns.Contains("Change"))
                {
                    dgvTransactions.Columns["Change"].DefaultCellStyle.Format = "C2";
                    dgvTransactions.Columns["Change"].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvTransactions.Columns["Change"].HeaderText = "Change (PHP)";
                }

                decimal totalSales = 0;
                foreach (DataRow row in dt.Rows)
                {
                    totalSales += Convert.ToDecimal(row["TotalAmount"]);
                }

                lblTotalSales.Text = $"Total Sales: ₱{totalSales:N2}";
                lblTransactionCount.Text = $"{dt.Rows.Count} transactions";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading transactions: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnViewDetails_Click(object sender, EventArgs e)
        {
            if (dgvTransactions.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a transaction to view details.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int transactionId = Convert.ToInt32(dgvTransactions.SelectedRows[0].Cells["TransactionID"].Value);
                DataTable dt = dbManager.GetTransactionItems(transactionId);
                dgvTransactionItems.DataSource = dt;

                if (dgvTransactionItems.Columns.Contains("UnitPrice"))
                {
                    dgvTransactionItems.Columns["UnitPrice"].DefaultCellStyle.Format = "C2";
                    dgvTransactionItems.Columns["UnitPrice"].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvTransactionItems.Columns["UnitPrice"].HeaderText = "Price (PHP)";
                }
                if (dgvTransactionItems.Columns.Contains("Subtotal"))
                {
                    dgvTransactionItems.Columns["Subtotal"].DefaultCellStyle.Format = "C2";
                    dgvTransactionItems.Columns["Subtotal"].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvTransactionItems.Columns["Subtotal"].HeaderText = "Subtotal (PHP)";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading transaction details: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvTransactions_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvTransactions.SelectedRows.Count > 0)
            {
                btnViewDetails_Click(sender, e);
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTransactions.Rows.Count == 0)
                {
                    MessageBox.Show("No data to export.", "Export",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                    Title = "Export Transaction History",
                    FileName = $"TransactionHistory_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string csvContent = CsvHelper.DataGridViewToCsv(dgvTransactions);
                    System.IO.File.WriteAllText(saveFileDialog.FileName, csvContent);

                    MessageBox.Show("Transaction history exported successfully!", "Export Complete",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error exporting data: {ex.Message}", "Export Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}