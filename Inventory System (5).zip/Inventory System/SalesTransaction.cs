using System;
using System.Collections.Generic;
using System.Linq;

namespace KidsMerch
{
    /// <summary>
    /// Represents a complete sales transaction with multiple items
    /// </summary>
    public class SalesTransaction
    {
        public int TransactionID { get; set; }
        public DateTime TransactionDate { get; set; }
        public string CustomerName { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal Change { get; set; }
        public string PaymentMethod { get; set; }
        public string Notes { get; set; }
        public List<SalesTransactionItem> Items { get; set; }

        public SalesTransaction()
        {
            TransactionDate = DateTime.Now;
            Items = new List<SalesTransactionItem>();
            CustomerName = "Walk-in Customer";
            PaymentMethod = "Cash";
        }

        /// <summary>
        /// Calculate total amount from all items
        /// </summary>
        public void CalculateTotal()
        {
            TotalAmount = Items.Sum(item => item.Subtotal);
            Change = AmountPaid - TotalAmount;
        }

        /// <summary>
        /// Get total number of items in transaction
        /// </summary>
        public int TotalItemCount
        {
            get { return Items.Sum(item => item.Quantity); }
        }

        /// <summary>
        /// Check if payment is sufficient
        /// </summary>
        public bool IsPaymentSufficient
        {
            get { return AmountPaid >= TotalAmount; }
        }

        /// <summary>
        /// Get formatted total with currency
        /// </summary>
        public string FormattedTotal
        {
            get { return TotalAmount.ToString("C2"); }
        }

        public override string ToString()
        {
            return $"Transaction #{TransactionID} - {TransactionDate:MM/dd/yyyy} - {FormattedTotal}";
        }
    }
}
