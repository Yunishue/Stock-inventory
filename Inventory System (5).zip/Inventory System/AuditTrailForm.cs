using System;
using System.Data;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class AuditTrailForm : Form
    {
        private DatabaseManager dbManager;
        public AuditTrailForm(DatabaseManager dbManager)
        {
            InitializeComponent();
            this.dbManager = dbManager;
        }

        private void AuditTrailForm_Load(object sender, EventArgs e)
        {
            LoadAudit();
        }

        private void LoadAudit()
        {
            var dt = dbManager.GetAuditEntries(500);
            dgvAudit.DataSource = dt;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAudit();
        }
    }
}
