namespace KidsMerch
{
    partial class SettingsForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtConnectionString = new System.Windows.Forms.TextBox();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.chkUseDarkTheme = new System.Windows.Forms.CheckBox();
            this.chkFollowOSTheme = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Text = "Database Connection String";
            // 
            // txtConnectionString
            // 
            this.txtConnectionString.Location = new System.Drawing.Point(12, 35);
            this.txtConnectionString.Multiline = true;
            this.txtConnectionString.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtConnectionString.Size = new System.Drawing.Size(660, 140);
            this.txtConnectionString.PlaceholderText = "Server=.;Initial Catalog=KidsMerchDB;Integrated Security=True;TrustServerCertificate=True";
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(12, 185);
            this.btnTest.Size = new System.Drawing.Size(120, 32);
            this.btnTest.Text = "Test";
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // chkUseDarkTheme
            // 
            this.chkUseDarkTheme.Location = new System.Drawing.Point(150, 185);
            this.chkUseDarkTheme.Size = new System.Drawing.Size(140, 24);
            this.chkUseDarkTheme.Text = "Use Dark Theme";
            this.chkUseDarkTheme.CheckedChanged += new System.EventHandler(this.chkUseDarkTheme_CheckedChanged);
            // 
            // chkFollowOSTheme
            // 
            this.chkFollowOSTheme.Location = new System.Drawing.Point(300, 185);
            this.chkFollowOSTheme.Size = new System.Drawing.Size(180, 24);
            this.chkFollowOSTheme.Text = "Follow OS Theme";
            this.chkFollowOSTheme.CheckedChanged += new System.EventHandler(this.chkFollowOSTheme_CheckedChanged);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(552, 185);
            this.btnSave.Size = new System.Drawing.Size(120, 32);
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(426, 185);
            this.btnCancel.Size = new System.Drawing.Size(120, 32);
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(12, 225);
            this.lblStatus.Size = new System.Drawing.Size(0, 15);
            this.lblStatus.ForeColor = System.Drawing.Color.SteelBlue;
            // 
            // SettingsForm
            // 
            this.ClientSize = new System.Drawing.Size(684, 251);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.chkFollowOSTheme);
            this.Controls.Add(this.chkUseDarkTheme);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.txtConnectionString);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Settings";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtConnectionString;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.CheckBox chkUseDarkTheme;
        private System.Windows.Forms.CheckBox chkFollowOSTheme;
    }
}
