using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class CreateUserDialog : Form
    {
        public string Username => txtUsername.Text.Trim();
        public string Password => txtPassword.Text;
        public string Role => cmbRole.SelectedItem?.ToString() ?? "cashier";
        public string FullName => txtFullName.Text.Trim();

        public CreateUserDialog()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            {
                MessageBox.Show("Username and password are required.");
                return;
            }

            if (!IsStrongPassword(Password))
            {
                MessageBox.Show("Password must be at least 8 characters, include uppercase, lowercase, digit and special character.");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private bool IsStrongPassword(string pwd)
        {
            if (pwd.Length < 8) return false;
            if (!Regex.IsMatch(pwd, "[A-Z]")) return false;
            if (!Regex.IsMatch(pwd, "[a-z]")) return false;
            if (!Regex.IsMatch(pwd, "[0-9]")) return false;
            if (!Regex.IsMatch(pwd, "[^a-zA-Z0-9]")) return false;
            return true;
        }
    }
}
