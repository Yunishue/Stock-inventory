using System;

namespace KidsMerch
{
    /// <summary>
    /// Model class representing a clothing inventory item
    /// </summary>
    public class ClothingItem
    {
        public int ItemID { get; set; }
        public string ItemName { get; set; }
        public string Category { get; set; }
        public string Size { get; set; }
        public string Color { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public string Supplier { get; set; }
        public DateTime DateAdded { get; set; }

        public ClothingItem()
        {
            DateAdded = DateTime.Now;
        }

        /// <summary>
        /// Calculate total value of this item in inventory
        /// </summary>
        public decimal TotalValue
        {
            get { return Quantity * Price; }
        }

        /// <summary>
        /// Check if item is low in stock (less than 10 units)
        /// </summary>
        public bool IsLowStock
        {
            get { return Quantity < 10; }
        }

        /// <summary>
        /// Get formatted price with currency symbol
        /// </summary>
        public string FormattedPrice
        {
            get { return Price.ToString("C2"); }
        }

        public override string ToString()
        {
            return $"{ItemName} - {Category} ({Size}, {Color})";
        }
    }
}
