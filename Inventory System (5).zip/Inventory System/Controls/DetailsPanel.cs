using System;
using System.Drawing;
using System.Windows.Forms;

namespace KidsMerch.Controls
{
    public partial class DetailsPanel : UserControl
    {
        public TextBox TxtItemID { get; private set; }
        public TextBox TxtItemName { get; private set; }
        public ComboBox CmbCategory { get; private set; }
        public ComboBox CmbSize { get; private set; }
        public TextBox TxtColor { get; private set; }
        public NumericUpDown NudQuantity { get; private set; }
        public TextBox TxtPrice { get; private set; }
        public TextBox TxtSupplier { get; private set; }
        public Button BtnSave { get; private set; }
        public Button BtnCancel { get; private set; }

        public DetailsPanel()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Configure the container
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(43, 47, 51);
            this.Dock = DockStyle.Right;
            this.MinimumSize = new Size(320, 400);
            this.Size = new Size(420, 600);
            this.Padding = new Padding(20);

            // Create TableLayoutPanel for stable layout
            var table = new TableLayoutPanel
            {
                ColumnCount = 1,
                RowCount = 20,
                Dock = DockStyle.Fill,
                AutoSize = false,
                CellBorderStyle = TableLayoutPanelCellBorderStyle.None,
                BackColor = Color.Transparent
            };

            // Configure rows
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Title
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 8F));  // Space
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // ItemID Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // ItemID Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Name Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Name Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Category Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Category Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Size Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Size Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Color Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Color Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Quantity Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Quantity Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Price Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Price Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F)); // Supplier Label
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F)); // Supplier Input
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 12F)); // Space before buttons
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F)); // Buttons

            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            // Title
            var lblTitle = new Label
            {
                Text = "Item Details",
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(235, 239, 241),
                AutoSize = false,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };

            // ItemID (read-only)
            var lblItemID = CreateLabel("Item ID:");
            TxtItemID = CreateTextBox();
            TxtItemID.ReadOnly = true;
            TxtItemID.BackColor = Color.FromArgb(38, 42, 48);

            // ItemName
            var lblItemName = CreateLabel("Item Name:");
            TxtItemName = CreateTextBox();

            // Category
            var lblCategory = CreateLabel("Category:");
            CmbCategory = CreateComboBox();

            // Size
            var lblSize = CreateLabel("Size:");
            CmbSize = CreateComboBox();

            // Color
            var lblColor = CreateLabel("Color:");
            TxtColor = CreateTextBox();

            // Quantity
            var lblQuantity = CreateLabel("Quantity:");
            NudQuantity = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F),
                Minimum = 0,
                Maximum = 999999,
                BackColor = Color.FromArgb(64, 68, 72),
                ForeColor = Color.FromArgb(235, 239, 241),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Price
            var lblPrice = CreateLabel("Price (PHP):");
            TxtPrice = CreateTextBox();

            // Supplier
            var lblSupplier = CreateLabel("Supplier:");
            TxtSupplier = CreateTextBox();

            // Buttons panel - fixed at bottom, no wrap, stable sizing
            var pnlButtons = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                AutoSize = false,
                Dock = DockStyle.Fill,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };

            BtnSave = new Button
            {
                Text = "?? Save",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                BackColor = Color.FromArgb(0, 150, 158),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                AutoSize = false,
                Size = new Size(120, 36),
                Margin = new Padding(0, 0, 8, 0),
                Cursor = Cursors.Hand
            };
            BtnSave.FlatAppearance.BorderSize = 0;

            BtnCancel = new Button
            {
                Text = "? Cancel",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                BackColor = Color.FromArgb(43, 47, 51),
                ForeColor = Color.FromArgb(235, 239, 241),
                FlatStyle = FlatStyle.Flat,
                AutoSize = false,
                Size = new Size(120, 36),
                Margin = new Padding(0),
                Cursor = Cursors.Hand
            };
            BtnCancel.FlatAppearance.BorderSize = 1;
            BtnCancel.FlatAppearance.BorderColor = Color.FromArgb(100, 105, 110);

            pnlButtons.Controls.Add(BtnSave);
            pnlButtons.Controls.Add(BtnCancel);

            // Add all to table
            int row = 0;
            table.Controls.Add(lblTitle, 0, row++);
            row++; // space
            table.Controls.Add(lblItemID, 0, row++);
            table.Controls.Add(TxtItemID, 0, row++);
            table.Controls.Add(lblItemName, 0, row++);
            table.Controls.Add(TxtItemName, 0, row++);
            table.Controls.Add(lblCategory, 0, row++);
            table.Controls.Add(CmbCategory, 0, row++);
            table.Controls.Add(lblSize, 0, row++);
            table.Controls.Add(CmbSize, 0, row++);
            table.Controls.Add(lblColor, 0, row++);
            table.Controls.Add(TxtColor, 0, row++);
            table.Controls.Add(lblQuantity, 0, row++);
            table.Controls.Add(NudQuantity, 0, row++);
            table.Controls.Add(lblPrice, 0, row++);
            table.Controls.Add(TxtPrice, 0, row++);
            table.Controls.Add(lblSupplier, 0, row++);
            table.Controls.Add(TxtSupplier, 0, row++);
            row++; // space
            table.Controls.Add(pnlButtons, 0, row++);

            this.Controls.Add(table);
            this.ResumeLayout(false);
        }

        private Label CreateLabel(string text)
        {
            return new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(200, 205, 208),
                AutoSize = false,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.BottomLeft,
                Padding = new Padding(0, 0, 0, 4)
            };
        }

        private TextBox CreateTextBox()
        {
            return new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F),
                BackColor = Color.FromArgb(64, 68, 72),
                ForeColor = Color.FromArgb(235, 239, 241),
                BorderStyle = BorderStyle.FixedSingle
            };
        }

        private ComboBox CreateComboBox()
        {
            return new ComboBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F),
                BackColor = Color.FromArgb(64, 68, 72),
                ForeColor = Color.FromArgb(235, 239, 241),
                FlatStyle = FlatStyle.Flat,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
        }
    }
}
