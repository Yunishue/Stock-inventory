using System;
using System.Drawing;
using System.Windows.Forms;

namespace KidsMerch.Controls
{
    public class ThemedComboBox : UserControl
    {
        private ComboBox inner;
        public ThemedComboBox()
        {
            inner = new ComboBox { /*Dock = DockStyle.Fill,*/ FlatStyle = FlatStyle.Flat };
            this.Padding = new Padding(6);
            this.Controls.Add(inner);
            ThemeManager.ThemeChanged += () => this.Invalidate();
        }

        public ComboBox.ObjectCollection Items => inner.Items;
        public object SelectedItem { get => inner.SelectedItem; set => inner.SelectedItem = value; }
        public int SelectedIndex { get => inner.SelectedIndex; set => inner.SelectedIndex = value; }
        public ComboBoxStyle DropDownStyle { get => inner.DropDownStyle; set => inner.DropDownStyle = value; }

        // Expose inner ComboBox so existing form fields can reference it directly
        public ComboBox InnerComboBox => inner;

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            var rect = this.ClientRectangle;
            rect.Inflate(-1, -1);
            Color border = ThemeManager.Active.Border;
            Color background = ThemeManager.Active.InputBackground;
            using (var b = new SolidBrush(background)) g.FillRectangle(b, rect);
            using (var p = new Pen(border, 1)) g.DrawRectangle(p, rect.X, rect.Y, rect.Width - 1, rect.Height - 1);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            // Position inner combobox accounting for padding so DropDown aligns to inner control
            int left = this.Padding.Left;
            int top = this.Padding.Top;
            int w = Math.Max(50, this.ClientSize.Width - this.Padding.Left - this.Padding.Right);
            int h = inner.PreferredHeight;
            inner.Location = new Point(left, top);
            inner.Size = new Size(w, h);

            // ensure dropdown width at least control width
            try { inner.DropDownWidth = Math.Max(w, inner.DropDownWidth); } catch { }

            this.Height = h + this.Padding.Top + this.Padding.Bottom;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            this.PerformLayout();
        }

        // Expose events by forwarding to inner control so no backing fields are required
        public event EventHandler SelectedIndexChanged
        {
            add { inner.SelectedIndexChanged += value; }
            remove { inner.SelectedIndexChanged -= value; }
        }

        public event EventHandler DropDown
        {
            add { inner.DropDown += value; }
            remove { inner.DropDown -= value; }
        }
    }
}
