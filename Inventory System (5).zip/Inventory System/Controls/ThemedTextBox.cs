using System;
using System.Drawing;
using System.Windows.Forms;

namespace KidsMerch.Controls
{
    // Simple wrapper that draws a themed border around a TextBox.
    public class ThemedTextBox : UserControl
    {
        private TextBox inner;

        public ThemedTextBox()
        {
            inner = new TextBox { BorderStyle = BorderStyle.None, Multiline = false };
            this.Padding = new Padding(8, 6, 8, 6);
            this.Height = inner.PreferredHeight + this.Padding.Top + this.Padding.Bottom;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(inner);

            this.inner.TextChanged += (s, e) => this.OnTextChanged(e);

            // update when theme changes
            ThemeManager.ThemeChanged += () => this.Invalidate();
        }

        // Expose the inner TextBox so caller can reuse original field references
        public TextBox InnerTextBox => inner;

        public override string Text { get => inner.Text; set => inner.Text = value; }
        public bool ReadOnly { get => inner.ReadOnly; set => inner.ReadOnly = value; }
        public new Font Font { get => inner.Font; set { inner.Font = value; base.Font = value; } }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            var rect = this.ClientRectangle;
            rect.Inflate(-1, -1);

            Color border = ThemeManager.Active.Border;
            Color background = ThemeManager.Active.InputBackground;
            if (inner.ReadOnly) background = Color.FromArgb(38, 42, 48);

            using (var b = new SolidBrush(background)) g.FillRectangle(b, rect);
            using (var p = new Pen(border, 1)) g.DrawRectangle(p, rect.X, rect.Y, rect.Width - 1, rect.Height - 1);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            // position inner textbox within padding
            int left = this.Padding.Left;
            int top = this.Padding.Top;
            int w = Math.Max(50, this.ClientSize.Width - this.Padding.Left - this.Padding.Right);
            int h = inner.PreferredHeight;
            inner.Location = new Point(left, top);
            inner.Size = new Size(w, h);

            this.Height = h + this.Padding.Top + this.Padding.Bottom;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            this.PerformLayout();
        }
    }
}
