using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace KidsMerch
{
    public enum ThemeType { Light, Dark }

    public class ThemeDefinition
    {
        public Color Background { get; set; }
        public Color PanelBackground { get; set; }
        public Color Primary { get; set; }
        public Color PrimaryDark { get; set; }
        public Color Accent { get; set; }
        public Color TextPrimary { get; set; }
        public Color TextSecondary { get; set; }
        public Color Border { get; set; }
        public Color InputBackground { get; set; }
        public Color InputDisabled { get; set; }
        public Color GridBackground { get; set; }
        public Color GridAlternate { get; set; }
        public Color GridHeader { get; set; }
        public Color GridSelection { get; set; }
        public Color Success { get; set; }
        public Color Warning { get; set; }
        public Color Error { get; set; }
        public Color Info { get; set; }
    }

    public static class ThemeManager
    {
        // When true, applying a theme will NOT change control sizes, fonts or margins.
        public static bool PreserveLayoutOnThemeApply { get; set; } = true;

        public static readonly ThemeDefinition LightPalette = new ThemeDefinition
        {
            Background = Color.FromArgb(248, 250, 252),
            PanelBackground = Color.FromArgb(255, 255, 255),
            Primary = Color.FromArgb(14, 165, 233),
            PrimaryDark = Color.FromArgb(3, 105, 161),
            Accent = Color.FromArgb(99, 102, 241),
            TextPrimary = Color.FromArgb(15, 23, 42),
            TextSecondary = Color.FromArgb(71, 85, 105),
            Border = Color.FromArgb(226, 232, 240),
            InputBackground = Color.FromArgb(255, 255, 255),
            InputDisabled = Color.FromArgb(241, 245, 249),
            GridBackground = Color.FromArgb(255, 255, 255),
            GridAlternate = Color.FromArgb(248, 250, 252),
            GridHeader = Color.FromArgb(14, 165, 233),
            GridSelection = Color.FromArgb(224, 242, 254),
            Success = Color.FromArgb(16, 185, 129),
            Warning = Color.FromArgb(245, 158, 11),
            Error = Color.FromArgb(239, 68, 68),
            Info = Color.FromArgb(59, 130, 246)
        };

        public static readonly ThemeDefinition DarkPalette = new ThemeDefinition
        {
            // neutral grey background for better contrast
            Background = Color.FromArgb(57, 62, 67),        // mid grey
            PanelBackground = Color.FromArgb(43, 47, 51),   // slightly darker panel
            Primary = Color.FromArgb(0, 150, 158),         // slightly muted teal/cyan accent
            PrimaryDark = Color.FromArgb(0, 120, 125),
            Accent = Color.FromArgb(150, 120, 200),
            TextPrimary = Color.FromArgb(235, 239, 241),    // near-white for labels
            TextSecondary = Color.FromArgb(200, 205, 208),  // muted light
            Border = Color.FromArgb(100, 105, 110),            // subtle but visible border
            InputBackground = Color.FromArgb(64, 68, 72), // slightly lighter than panel for inputs
            InputDisabled = Color.FromArgb(80, 84, 88),
            GridBackground = Color.FromArgb(50, 55, 60),
            GridAlternate = Color.FromArgb(58, 63, 68),
            GridHeader = Color.FromArgb(38, 43, 48),
            GridSelection = Color.FromArgb(0, 120, 130),
            Success = Color.FromArgb(0, 200, 120),
            Warning = Color.FromArgb(255, 179, 0),
            Error = Color.FromArgb(239, 68, 68),
            Info = Color.FromArgb(0, 150, 158)
        };

        private static ThemeDefinition _active = DarkPalette;
        public static ThemeDefinition Active => _active;
        public static ThemeDefinition LightTheme => Active;
        public static ThemeType CurrentThemeType { get; private set; } = ThemeType.Dark;

        // Event fired after theme is changed so custom controls can react
        public static event Action ThemeChanged;

        public static void SetTheme(ThemeType theme)
        {
            CurrentThemeType = theme;
            _active = theme == ThemeType.Dark ? DarkPalette : LightPalette;

            // Apply to all open forms
            foreach (Form f in Application.OpenForms)
            {
                try { ApplyTheme(f); }
                catch { }
            }

            // notify subscribers (custom controls)
            try { ThemeChanged?.Invoke(); } catch { }
        }

        public static void ApplyTheme(Form form)
        {
            if (form == null) return;
            // Always apply colors
            form.BackColor = Active.Background;
            form.ForeColor = Active.TextPrimary;

            // Only change font when layout changes are allowed
            if (!PreserveLayoutOnThemeApply)
            {
                form.Font = new Font("Segoe UI", 10F); // slightly larger for accessibility
            }

            ApplyThemeToControls(form.Controls, PreserveLayoutOnThemeApply);

            // Ensure menu/toolbars dock and size properly to avoid overlap only when allowed
            try
            {
                if (!PreserveLayoutOnThemeApply)
                {
                    foreach (Control c in form.Controls)
                    {
                        if (c is MenuStrip ms)
                        {
                            ms.Dock = DockStyle.Top;
                            ms.AutoSize = false;
                            ms.Height = Math.Max(30, (int)(form.Font.Size * 3.2));
                            ms.Padding = new Padding(6, 4, 6, 4);
                        }
                        else if (c is ToolStrip ts)
                        {
                            ts.Dock = DockStyle.Top;
                            ts.AutoSize = false;
                            ts.Height = Math.Max(44, (int)(form.Font.Size * 5));
                            ts.Padding = new Padding(6);
                        }
                    }
                }

                // Force layout update
                form.PerformLayout();
                foreach (Control c in form.Controls)
                {
                    try { c.PerformLayout(); c.Refresh(); } catch { }
                }

                // Specific overlap adjustments remain but only run if layout changes allowed
                if (!PreserveLayoutOnThemeApply)
                {
                    try
                    {
                        Control FindControl(Control parent, string name)
                        {
                            if (parent == null) return null;
                            foreach (Control ch in parent.Controls)
                            {
                                if (string.Equals(ch.Name, name, StringComparison.OrdinalIgnoreCase)) return ch;
                                var found = FindControl(ch, name);
                                if (found != null) return found;
                            }
                            return null;
                        }

                        var nud = FindControl(form, "nudQuantity");
                        var txtColor = FindControl(form, "txtColor");
                        var txtPrice = FindControl(form, "txtPrice");
                        var lblPrice = FindControl(form, "lblPrice");

                        if (nud != null && txtColor != null)
                        {
                            int desiredTop = txtColor.Bottom + 8;
                            if (nud.Top < desiredTop)
                            {
                                nud.Top = desiredTop;
                            }

                            nud.Left = txtColor.Left;
                            nud.Width = txtColor.Width;

                            if (txtPrice != null && txtPrice.Top <= nud.Bottom)
                            {
                                txtPrice.Top = nud.Bottom + 12;
                                if (lblPrice != null) lblPrice.Top = txtPrice.Top - 30;
                            }
                        }
                    }
                    catch { }
                }

                form.Refresh();
            }
            catch { }
        }

        private static void ApplyThemeToControls(Control.ControlCollection controls, bool preserveLayout)
        {
            foreach (Control control in controls)
            {
                try
                {
                    switch (control)
                    {
                        case Button b: ApplyButtonTheme(b, preserveLayout); break;
                        case Panel p: ApplyPanelTheme(p); break;
                        case Label l: ApplyLabelTheme(l, preserveLayout); break;
                        case TextBox t: ApplyTextBoxTheme(t, preserveLayout); break;
                        case ComboBox cb: ApplyComboBoxTheme(cb, preserveLayout); break;
                        case NumericUpDown nud: ApplyNumericUpDownTheme(nud, preserveLayout); break;
                        case DataGridView g: ApplyDataGridViewTheme(g, preserveLayout); break;
                        case StatusStrip ss: ApplyStatusStripTheme(ss); break;
                        case MenuStrip ms: ApplyMenuStripTheme(ms); break;
                        case ToolStrip ts: ApplyToolStripTheme(ts); break;
                        case RichTextBox rtb: rtb.BackColor = Active.InputBackground; rtb.ForeColor = Active.TextPrimary; break;
                        default:
                            control.BackColor = Active.PanelBackground;
                            control.ForeColor = Active.TextPrimary;
                            break;
                    }

                    if (control.HasChildren) ApplyThemeToControls(control.Controls, preserveLayout);
                }
                catch { }
            }
        }

        private static void ApplyPanelTheme(Panel panel)
        {
            panel.BackColor = Active.PanelBackground;
            panel.ForeColor = Active.TextPrimary;
        }

        private static void ApplyLabelTheme(Label label, bool preserveLayout)
        {
            label.ForeColor = Active.TextPrimary;
            if (!preserveLayout && label.Name?.ToLowerInvariant().Contains("title") == true)
            {
                label.ForeColor = Active.Primary;
                label.Font = new Font(label.Font.FontFamily, 13F, FontStyle.Bold);
            }
            else if (!preserveLayout)
            {
                label.Font = new Font(label.Font.FontFamily, 10F);
            }

            if (!preserveLayout)
            {
                try { label.Margin = new Padding(0, 6, 0, 6); } catch { }
            }
        }

        private static void ApplyTextBoxTheme(TextBox textBox, bool preserveLayout)
        {
            textBox.BackColor = Active.InputBackground;
            textBox.ForeColor = Active.TextPrimary;
            textBox.BorderStyle = BorderStyle.FixedSingle;
            if (!preserveLayout)
            {
                textBox.Font = new Font(textBox.Font.FontFamily, 10F);
                textBox.Height = Math.Max(28, (int)(textBox.Font.Height * 2.2));
                textBox.Margin = new Padding(0, 4, 0, 8);
            }
            if (textBox.ReadOnly)
            {
                // improved disabled styling for dark theme
                textBox.BackColor = Color.FromArgb(38, 42, 48);
                textBox.ForeColor = Active.TextSecondary;
            }
            // border color tweak for visibility
            try
            {
                textBox.BorderStyle = BorderStyle.FixedSingle;
                // no direct border color on TextBox (requires custom painting) - skip
            }
            catch { }
        }

        private static void ApplyComboBoxTheme(ComboBox comboBox, bool preserveLayout)
        {
            comboBox.BackColor = Active.InputBackground;
            comboBox.ForeColor = Active.TextPrimary;
            comboBox.FlatStyle = FlatStyle.Flat;
            if (!preserveLayout)
            {
                comboBox.Font = new Font(comboBox.Font.FontFamily, 10F);
                comboBox.Height = Math.Max(28, (int)(comboBox.Font.Height * 2.2));
                comboBox.Margin = new Padding(0, 4, 0, 8);
            }
            if (!preserveLayout && Active == DarkPalette)
            {
                comboBox.BackColor = Color.FromArgb(28, 32, 36);
                comboBox.ForeColor = Active.TextPrimary;
            }
        }

        private static void ApplyNumericUpDownTheme(NumericUpDown numericUpDown, bool preserveLayout)
        {
            numericUpDown.BackColor = Active.InputBackground;
            numericUpDown.ForeColor = Active.TextPrimary;
            numericUpDown.BorderStyle = BorderStyle.FixedSingle;
            if (!preserveLayout)
            {
                numericUpDown.Font = new Font(numericUpDown.Font.FontFamily, 10F);
                numericUpDown.Height = Math.Max(28, (int)(numericUpDown.Font.Height * 2.2));
                numericUpDown.Margin = new Padding(0, 4, 0, 8);
            }
            if (!preserveLayout && Active == DarkPalette)
            {
                numericUpDown.BackColor = Color.FromArgb(28, 32, 36);
                numericUpDown.ForeColor = Active.TextPrimary;
            }
        }

        private static void ApplyDataGridViewTheme(DataGridView grid, bool preserveLayout)
        {
            grid.EnableHeadersVisualStyles = false;
            grid.BackgroundColor = Active.GridBackground;
            grid.GridColor = Active.Border;

            grid.DefaultCellStyle.BackColor = Active.GridBackground;
            grid.DefaultCellStyle.ForeColor = Active.TextPrimary;
            grid.DefaultCellStyle.SelectionBackColor = Active.GridSelection;
            grid.DefaultCellStyle.SelectionForeColor = Color.White;

            grid.AlternatingRowsDefaultCellStyle.BackColor = Active.GridAlternate;
            grid.AlternatingRowsDefaultCellStyle.ForeColor = Active.TextPrimary;

            grid.ColumnHeadersDefaultCellStyle.BackColor = Active.GridHeader;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Active.TextPrimary;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font(grid.Font, FontStyle.Bold);

            grid.RowHeadersVisible = false;
            grid.BorderStyle = BorderStyle.None;
            if (!preserveLayout)
            {
                grid.Font = new Font(grid.Font.FontFamily, 10F);
            }
        }

        private static void ApplyStatusStripTheme(StatusStrip statusStrip)
        {
            statusStrip.BackColor = Active.PanelBackground;
            foreach (ToolStripItem item in statusStrip.Items) item.ForeColor = Active.TextSecondary;
        }

        private static void ApplyMenuStripTheme(MenuStrip menuStrip)
        {
            menuStrip.BackColor = Active.PanelBackground;
            menuStrip.RenderMode = ToolStripRenderMode.System;
            foreach (ToolStripItem item in menuStrip.Items) item.ForeColor = Active.TextPrimary;
        }

        private static void ApplyToolStripTheme(ToolStrip toolStrip)
        {
            toolStrip.BackColor = Active.PanelBackground;
            toolStrip.RenderMode = ToolStripRenderMode.System;
            foreach (ToolStripItem item in toolStrip.Items) item.ForeColor = Active.TextPrimary;
        }

        private static void ApplyButtonTheme(Button button, bool preserveLayout)
        {
            Color bg = Active.PrimaryDark;
            if (button.Name == null) button.Name = string.Empty;
            var name = button.Name.ToLowerInvariant();
            if (name.Contains("add") || name.Contains("save")) bg = Active.Primary;
            else if (name.Contains("delete") || name.Contains("remove")) bg = Active.Error;
            else if (name.Contains("cancel") || name.Contains("close")) bg = Active.PanelBackground;
            else if (name.Contains("export") || name.Contains("print")) bg = Active.Accent;
            else if (name.Contains("search") || name.Contains("refresh")) bg = Active.PrimaryDark;

            button.BackColor = bg;
            // Use white text for colored buttons for better readability; if bg equals panel background use TextPrimary
            if (bg.ToArgb() == Active.PanelBackground.ToArgb())
            {
                button.ForeColor = Active.TextPrimary;
            }
            else
            {
                button.ForeColor = Color.White;
            }
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            if (!preserveLayout)
            {
                button.Padding = new Padding(10, 8, 10, 8);
                button.Font = new Font(button.Font.FontFamily, 10F, FontStyle.Bold);
            }
        }

        public static Color GetContrastColor(Color bg)
        {
            // Calculate relative luminance
            double r = bg.R / 255.0;
            double g = bg.G / 255.0;
            double b = bg.B / 255.0;
            double luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
            return luminance < 0.5 ? Color.White : Color.FromArgb(8, 10, 12);
        }

        public static ThemeType GetSystemTheme()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize"))
                {
                    if (key != null)
                    {
                        var val = key.GetValue("AppsUseLightTheme");
                        if (val is int i)
                        {
                            return i == 0 ? ThemeType.Dark : ThemeType.Light;
                        }
                    }
                }
            }
            catch { }
            return ThemeType.Dark;
        }
    }
}
