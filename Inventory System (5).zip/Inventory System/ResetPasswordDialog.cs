using System;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class ResetPasswordDialog : Form
    {
        public string NewPassword => txtNewPassword.Text;
        public ResetPasswordDialog()
        {
            InitializeComponent();
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNewPassword.Text))
            {
                MessageBox.Show("Enter new password.");
                return;
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
