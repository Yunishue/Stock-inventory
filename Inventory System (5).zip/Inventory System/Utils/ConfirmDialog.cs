using System;
using System.Drawing;
using System.Windows.Forms;

namespace KidsMerch
{
    public class ConfirmDialog : Form
    {
        private Label messageLabel;
        private Button btnYes;
        private Button btnNo;
        private Button btnCancel;

        private ConfirmDialog(string message, string title, MessageBoxButtons buttons)
        {
            Text = title ?? "Confirm";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            Size = new Size(520, 160);

            messageLabel = new Label
            {
                Text = message,
                Dock = DockStyle.Fill,
                // allow multi-line wrapping and occupy available space above buttons
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12),
                Font = new Font("Segoe UI", 10F)
            };

            var panel = new Panel { Dock = DockStyle.Bottom, Height = 56, Padding = new Padding(8) };

            // Create buttons with consistent size so layout is predictable
            btnYes = new Button { Text = "Yes", DialogResult = DialogResult.Yes, Name = "btnYes", Size = new Size(90, 34) };
            btnNo = new Button { Text = "No", DialogResult = DialogResult.No, Name = "btnNo", Size = new Size(90, 34) };
            btnCancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Name = "btnCancel", Size = new Size(90, 34) };

            // Arrange buttons right-aligned using a FlowLayoutPanel that fills the bottom panel
            FlowLayoutPanel fp = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false,
                AutoSize = false,
                Padding = new Padding(0),
                Margin = new Padding(0)
            };

            if (buttons == MessageBoxButtons.YesNoCancel)
            {
                fp.Controls.Add(btnCancel);
                fp.Controls.Add(btnNo);
                fp.Controls.Add(btnYes);
            }
            else if (buttons == MessageBoxButtons.YesNo)
            {
                fp.Controls.Add(btnNo);
                fp.Controls.Add(btnYes);
            }
            else
            {
                fp.Controls.Add(btnYes);
            }

            // Add a small spacer on the left so buttons don't touch form edge
            var spacer = new Panel { Dock = DockStyle.Left, Width = 8 };
            panel.Controls.Add(spacer);
            panel.Controls.Add(fp);

            Controls.Add(panel);
            Controls.Add(messageLabel);

            // Set Accept/Cancel appropriately
            if (buttons == MessageBoxButtons.YesNo || buttons == MessageBoxButtons.YesNoCancel)
            {
                AcceptButton = btnYes;
                CancelButton = (buttons == MessageBoxButtons.YesNoCancel) ? btnCancel : btnNo;
            }
            else
            {
                AcceptButton = btnYes;
                CancelButton = btnCancel;
            }

            // Apply theme and then tweak button colors for semantic clarity
            try
            {
                ThemeManager.ApplyTheme(this);

                // set explicit colors for buttons to ensure contrast
                btnYes.BackColor = ThemeManager.Active.Primary;
                btnYes.ForeColor = ThemeManager.Active.TextPrimary;

                btnNo.BackColor = ThemeManager.Active.PanelBackground;
                btnNo.ForeColor = ThemeManager.Active.TextPrimary;

                btnCancel.BackColor = ThemeManager.Active.PanelBackground;
                btnCancel.ForeColor = ThemeManager.Active.TextPrimary;

                // message text color
                messageLabel.ForeColor = ThemeManager.Active.TextPrimary;
                this.BackColor = ThemeManager.Active.PanelBackground;

                // improve button appearance
                foreach (Control c in fp.Controls)
                {
                    if (c is Button b)
                    {
                        b.FlatStyle = FlatStyle.Flat;
                        b.FlatAppearance.BorderSize = 0;
                        b.Margin = new Padding(6, 8, 6, 8);
                        b.UseVisualStyleBackColor = false;
                    }
                }

                // ensure neutral buttons (No/Cancel) remain visible against panel background by adding a subtle border and hover visual
                try
                {
                    foreach (var neutral in new[] { btnNo, btnCancel })
                    {
                        if (neutral == null) continue;
                        // If panel background is very close to button background, give button a border to make it visible
                        neutral.FlatAppearance.BorderSize = 1;
                        neutral.FlatAppearance.BorderColor = ThemeManager.Active.Border;

                        // Use slightly lighter/darker background for neutral buttons when needed
                        if (ThemeManager.Active.PanelBackground.GetBrightness() > 0.5f)
                        {
                            // light theme -> use a light-gray background
                            neutral.BackColor = ControlPaint.Light(ThemeManager.Active.PanelBackground);
                            neutral.ForeColor = ThemeManager.Active.TextPrimary;
                        }
                        else
                        {
                            // dark theme -> use slightly lighter panel color for contrast
                            neutral.BackColor = ControlPaint.Light(ThemeManager.Active.PanelBackground);
                            neutral.ForeColor = ThemeManager.Active.TextPrimary;
                        }

                        // Add simple mouse-over effect
                        neutral.MouseEnter += (s, e) => { try { ((Button)s).BackColor = ControlPaint.Light(ThemeManager.Active.PanelBackground); } catch { } };
                        neutral.MouseLeave += (s, e) => { try { ((Button)s).BackColor = ThemeManager.Active.PanelBackground; } catch { } };
                    }
                }
                catch { }
            }
            catch { }
        }

        public static DialogResult Show(Form owner, string message, string title = "Confirm", MessageBoxButtons buttons = MessageBoxButtons.YesNo)
        {
            var dlg = new ConfirmDialog(message, title, buttons);
            if (owner == null) return dlg.ShowDialog();
            return dlg.ShowDialog(owner);
        }
    }
}
