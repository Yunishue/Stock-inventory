using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace KidsMerch
{
    public class Toast : Form
    {
        private System.Windows.Forms.Timer lifeTimer;
        private Label messageLabel;

        public enum ToastType { Info, Success, Warning, Error }

        public Toast(string message, ToastType type = ToastType.Info, int durationMs = 3000)
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Opacity = 0.95;
            Padding = new Padding(12);

            messageLabel = new Label
            {
                AutoSize = false,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 9F),
                Text = message
            };

            Controls.Add(messageLabel);

            Size = new Size(360, 48);

            lifeTimer = new System.Windows.Forms.Timer();
            lifeTimer.Interval = durationMs;
            lifeTimer.Tick += (s, e) => { lifeTimer.Stop(); FadeOutAndClose(); };

            // background color per type using ThemeManager
            try
            {
                switch (type)
                {
                    case ToastType.Success: BackColor = ThemeManager.Active.Success; break;
                    case ToastType.Warning: BackColor = ThemeManager.Active.Warning; break;
                    case ToastType.Error: BackColor = ThemeManager.Active.Error; break;
                    default: BackColor = ThemeManager.Active.Info; break;
                }
                messageLabel.ForeColor = ThemeManager.Active.TextPrimary;
            }
            catch
            {
                // fallback
                BackColor = Color.DimGray;
                messageLabel.ForeColor = Color.White;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            lifeTimer.Start();
        }

        private async void FadeOutAndClose()
        {
            for (int i = 0; i < 10; i++)
            {
                await System.Threading.Tasks.Task.Delay(40);
                Opacity -= 0.08;
            }
            Close();
        }

        public static void Show(Form owner, string message, ToastType type = ToastType.Info, int durationMs = 3000)
        {
            try
            {
                var t = new Toast(message, type, durationMs);

                Rectangle screenArea;
                if (owner == null)
                {
                    screenArea = Screen.PrimaryScreen.WorkingArea;
                }
                else
                {
                    // get owner's client rectangle in screen coordinates
                    screenArea = owner.RectangleToScreen(owner.ClientRectangle);
                }

                int margin = 12;
                int x = screenArea.Right - t.Width - margin;
                int y = screenArea.Top + margin;

                // stack toasts: find existing toasts and push down
                var existing = new List<Toast>();
                foreach (Form f in Application.OpenForms)
                {
                    if (f is Toast) existing.Add((Toast)f);
                }
                y += existing.Count * (t.Height + 8);

                t.Location = new Point(x, y);
                // show without stealing focus
                t.Show(owner);
            }
            catch { }
        }
    }
}
