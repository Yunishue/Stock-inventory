using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace KidsMerch
{
    public class ReceiptPreviewForm : Form
    {
        private readonly string _receiptText;
        private RichTextBox rtb;
        private Button btnPrint;
        private Button btnClose;
        private PrintDocument printDoc;
        private int _printPosition;
        private Font _printFont = new Font("Consolas", 10f);

        public ReceiptPreviewForm(string receiptText)
        {
            _receiptText = receiptText ?? string.Empty;
            InitializeComponent();
            try { ThemeManager.ApplyTheme(this); }
            catch { }
        }

        private void InitializeComponent()
        {
            this.Text = "Receipt Preview";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 600;
            this.Height = 700;

            rtb = new RichTextBox
            {
                Dock = DockStyle.Top,
                Height = this.ClientSize.Height - 60,
                ReadOnly = true,
                Font = new Font("Consolas", 10f),
                Text = _receiptText
            };

            btnPrint = new Button { Text = "Print", Width = 100, Left = this.ClientSize.Width - 220, Top = this.ClientSize.Height - 50, Anchor = AnchorStyles.Bottom | AnchorStyles.Right, Name = "btnPrint" };
            btnClose = new Button { Text = "Close", Width = 100, Left = this.ClientSize.Width - 110, Top = this.ClientSize.Height - 50, Anchor = AnchorStyles.Bottom | AnchorStyles.Right, Name = "btnClose" };

            btnPrint.Click += BtnPrint_Click;
            btnClose.Click += (s, e) => this.Close();

            this.Controls.Add(rtb);
            this.Controls.Add(btnPrint);
            this.Controls.Add(btnClose);

            printDoc = new PrintDocument();
            printDoc.PrintPage += PrintDoc_PrintPage;
            this.FormClosing += (s, e) => printDoc.PrintPage -= PrintDoc_PrintPage;
        }

        private void BtnPrint_Click(object? sender, EventArgs e)
        {
            try
            {
                using (var pdialog = new PrintDialog())
                {
                    pdialog.Document = printDoc;
                    if (pdialog.ShowDialog(this) != DialogResult.OK) return;
                }

                _printPosition = 0;
                printDoc.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Print failed: {ex.Message}", "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PrintDoc_PrintPage(object? sender, PrintPageEventArgs e)
        {
            // Printable area
            var marginBounds = e.MarginBounds;
            var g = e.Graphics;

            // Measure how many characters fit
            int charsFitted, linesFilled;
            var layoutSize = new SizeF(marginBounds.Width, marginBounds.Height);
            var remaining = _receiptText.Substring(_printPosition);
            g.MeasureString(remaining, _printFont, layoutSize, StringFormat.GenericDefault, out charsFitted, out linesFilled);

            // Draw the substring that fits
            string textToPrint = remaining.Substring(0, Math.Min(charsFitted, remaining.Length));
            g.DrawString(textToPrint, _printFont, Brushes.Black, marginBounds.Location);

            _printPosition += charsFitted;
            e.HasMorePages = _printPosition < _receiptText.Length;
        }
    }
}
