using System.Drawing;
using System.Windows.Forms;

namespace KidsMerch
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panelTop = new Panel();
            this.lblTitle = new Label();
            this.panelSearch = new Panel();
            this.btnSearch = new Button();
            this.txtSearch = new TextBox();
            this.lblSearch = new Label();
            this.cmbSearchCategory = new ComboBox();
            this.lblSearchBy = new Label();
            this.btnRefresh = new Button();
            this.dgvInventory = new DataGridView();
            this.panelButtons = new Panel();
            this.btnAdd = new Button();
            this.btnEdit = new Button();
            this.btnDelete = new Button();
            this.btnExport = new Button();
            this.panelDetails = new Panel();
            this.lblItemDetails = new Label();
            this.lblItemID = new Label();
            this.txtItemID = new TextBox();
            this.lblItemName = new Label();
            this.txtItemName = new TextBox();
            this.lblCategory = new Label();
            this.cmbCategory = new ComboBox();
            this.lblSize = new Label();
            this.cmbSize = new ComboBox();
            this.lblColor = new Label();
            this.txtColor = new TextBox();
            this.lblQuantity = new Label();
            this.nudQuantity = new NumericUpDown();
            this.lblPrice = new Label();
            this.txtPrice = new TextBox();
            this.lblSupplier = new Label();
            this.txtSupplier = new TextBox();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.statusStrip1 = new StatusStrip();
            this.toolStripStatusLabel = new ToolStripStatusLabel();
            this.menuStrip1 = new MenuStrip();
            this.salesToolStripMenuItem = new ToolStripMenuItem();
            this.newSaleToolStripMenuItem = new ToolStripMenuItem();
            this.transactionHistoryToolStripMenuItem = new ToolStripMenuItem();
            this.inventoryToolStripMenuItem = new ToolStripMenuItem();
            this.archivedItemsToolStripMenuItem = new ToolStripMenuItem();
            this.importExportToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.generateTestDataToolStripMenuItem = new ToolStripMenuItem();
            this.generate10ItemsToolStripMenuItem = new ToolStripMenuItem();
            this.generate50ItemsToolStripMenuItem = new ToolStripMenuItem();
            this.generate100ItemsToolStripMenuItem = new ToolStripMenuItem();
            this.clearAllDataToolStripMenuItem = new ToolStripMenuItem();
            this.managementToolStripMenuItem = new ToolStripMenuItem();
            this.userManagementToolStripMenuItem = new ToolStripMenuItem();
            this.auditTrailToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator2 = new ToolStripSeparator();
            this.settingsToolStripMenuItem = new ToolStripMenuItem();
            this.reportsToolStripMenuItem = new ToolStripMenuItem();
            this.helpToolStripMenuItem = new ToolStripMenuItem();
            this.aboutToolStripMenuItem = new ToolStripMenuItem();
            
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            
            // menuStrip1
            this.menuStrip1.Font = new Font("Segoe UI", 9F);
            this.menuStrip1.Items.AddRange(new ToolStripItem[] {
                this.salesToolStripMenuItem,
                this.inventoryToolStripMenuItem,
                this.managementToolStripMenuItem,
                this.reportsToolStripMenuItem,
                this.helpToolStripMenuItem});
            this.menuStrip1.Location = new Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new Size(1400, 24);
            this.menuStrip1.TabIndex = 0;
            
            // salesToolStripMenuItem
            this.salesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] {
                this.newSaleToolStripMenuItem,
                this.transactionHistoryToolStripMenuItem});
            this.salesToolStripMenuItem.Name = "salesToolStripMenuItem";
            this.salesToolStripMenuItem.Size = new Size(45, 20);
            this.salesToolStripMenuItem.Text = "Sales";
            
            // newSaleToolStripMenuItem
            this.newSaleToolStripMenuItem.Name = "newSaleToolStripMenuItem";
            this.newSaleToolStripMenuItem.Size = new Size(180, 22);
            this.newSaleToolStripMenuItem.Text = "New Sale";
            this.newSaleToolStripMenuItem.Click += new System.EventHandler(this.newSaleToolStripMenuItem_Click);
            
            // transactionHistoryToolStripMenuItem
            this.transactionHistoryToolStripMenuItem.Name = "transactionHistoryToolStripMenuItem";
            this.transactionHistoryToolStripMenuItem.Size = new Size(180, 22);
            this.transactionHistoryToolStripMenuItem.Text = "Transaction History";
            this.transactionHistoryToolStripMenuItem.Click += new System.EventHandler(this.transactionHistoryToolStripMenuItem_Click);
            
            // inventoryToolStripMenuItem
            this.inventoryToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] {
                this.archivedItemsToolStripMenuItem,
                this.importExportToolStripMenuItem,
                this.toolStripSeparator1,
                this.generateTestDataToolStripMenuItem,
                this.clearAllDataToolStripMenuItem});
            this.inventoryToolStripMenuItem.Name = "inventoryToolStripMenuItem";
            this.inventoryToolStripMenuItem.Size = new Size(69, 20);
            this.inventoryToolStripMenuItem.Text = "Inventory";
            
            // archivedItemsToolStripMenuItem
            this.archivedItemsToolStripMenuItem.Name = "archivedItemsToolStripMenuItem";
            this.archivedItemsToolStripMenuItem.Size = new Size(180, 22);
            this.archivedItemsToolStripMenuItem.Text = "Archived Items";
            this.archivedItemsToolStripMenuItem.Click += new System.EventHandler(this.archivedItemsToolStripMenuItem_Click);
            
            // importExportToolStripMenuItem
            this.importExportToolStripMenuItem.Name = "importExportToolStripMenuItem";
            this.importExportToolStripMenuItem.Size = new Size(180, 22);
            this.importExportToolStripMenuItem.Text = "Import/Export...";
            this.importExportToolStripMenuItem.Click += new System.EventHandler(this.ImportExportToolStripMenuItem_Click);
            
            // toolStripSeparator1
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(177, 6);
            
            // generateTestDataToolStripMenuItem
            this.generateTestDataToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] {
                this.generate10ItemsToolStripMenuItem,
                this.generate50ItemsToolStripMenuItem,
                this.generate100ItemsToolStripMenuItem});
            this.generateTestDataToolStripMenuItem.Name = "generateTestDataToolStripMenuItem";
            this.generateTestDataToolStripMenuItem.Size = new Size(180, 22);
            this.generateTestDataToolStripMenuItem.Text = "Generate Test Data";
            
            // generate10ItemsToolStripMenuItem
            this.generate10ItemsToolStripMenuItem.Name = "generate10ItemsToolStripMenuItem";
            this.generate10ItemsToolStripMenuItem.Size = new Size(120, 22);
            this.generate10ItemsToolStripMenuItem.Text = "10 Items";
            this.generate10ItemsToolStripMenuItem.Click += new System.EventHandler(this.generate10ItemsToolStripMenuItem_Click);
            
            // generate50ItemsToolStripMenuItem
            this.generate50ItemsToolStripMenuItem.Name = "generate50ItemsToolStripMenuItem";
            this.generate50ItemsToolStripMenuItem.Size = new Size(120, 22);
            this.generate50ItemsToolStripMenuItem.Text = "50 Items";
            this.generate50ItemsToolStripMenuItem.Click += new System.EventHandler(this.generate50ItemsToolStripMenuItem_Click);
            
            // generate100ItemsToolStripMenuItem
            this.generate100ItemsToolStripMenuItem.Name = "generate100ItemsToolStripMenuItem";
            this.generate100ItemsToolStripMenuItem.Size = new Size(120, 22);
            this.generate100ItemsToolStripMenuItem.Text = "100 Items";
            this.generate100ItemsToolStripMenuItem.Click += new System.EventHandler(this.generate100ItemsToolStripMenuItem_Click);
            
            // clearAllDataToolStripMenuItem
            this.clearAllDataToolStripMenuItem.Name = "clearAllDataToolStripMenuItem";
            this.clearAllDataToolStripMenuItem.Size = new Size(180, 22);
            this.clearAllDataToolStripMenuItem.Text = "Clear All Data";
            this.clearAllDataToolStripMenuItem.Click += new System.EventHandler(this.clearAllDataToolStripMenuItem_Click);
            
            // managementToolStripMenuItem
            this.managementToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] {
                this.userManagementToolStripMenuItem,
                this.auditTrailToolStripMenuItem,
                this.toolStripSeparator2,
                this.settingsToolStripMenuItem});
            this.managementToolStripMenuItem.Name = "managementToolStripMenuItem";
            this.managementToolStripMenuItem.Size = new Size(90, 20);
            this.managementToolStripMenuItem.Text = "Management";
            
            // userManagementToolStripMenuItem
            this.userManagementToolStripMenuItem.Name = "userManagementToolStripMenuItem";
            this.userManagementToolStripMenuItem.Size = new Size(180, 22);
            this.userManagementToolStripMenuItem.Text = "User Management";
            this.userManagementToolStripMenuItem.Click += new System.EventHandler(this.userManagementToolStripMenuItem_Click);
            
            // auditTrailToolStripMenuItem
            this.auditTrailToolStripMenuItem.Name = "auditTrailToolStripMenuItem";
            this.auditTrailToolStripMenuItem.Size = new Size(180, 22);
            this.auditTrailToolStripMenuItem.Text = "Audit Trail";
            this.auditTrailToolStripMenuItem.Click += new System.EventHandler(this.auditTrailToolStripMenuItem_Click);
            
            // toolStripSeparator2
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new Size(177, 6);
            
            // settingsToolStripMenuItem
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new Size(180, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            
            // reportsToolStripMenuItem
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            
            // helpToolStripMenuItem
            this.helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { this.aboutToolStripMenuItem });
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            
            // aboutToolStripMenuItem
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            
            // panelTop
            this.panelTop.BackColor = Color.FromArgb(14, 165, 233);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock = DockStyle.Top;
            this.panelTop.Location = new Point(0, 24);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new Size(1400, 80);
            this.panelTop.TabIndex = 1;
            
            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Segoe UI", 28F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.White;
            this.lblTitle.Location = new Point(20, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(451, 51);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Kids Merch Inventory System";
            
            // panelSearch
            this.panelSearch.BackColor = Color.FromArgb(236, 240, 241);
            this.panelSearch.Dock = DockStyle.Top;
            this.panelSearch.Location = new Point(0, 104);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new Size(1400, 60);
            this.panelSearch.TabIndex = 2;
            
            // lblSearchBy
            this.lblSearchBy.AutoSize = true;
            this.lblSearchBy.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.lblSearchBy.ForeColor = Color.FromArgb(71, 85, 105);
            this.lblSearchBy.Location = new Point(20, 18);
            this.lblSearchBy.Name = "lblSearchBy";
            this.lblSearchBy.Size = new Size(80, 19);
            this.lblSearchBy.TabIndex = 0;
            this.lblSearchBy.Text = "Search By:";
            
            // cmbSearchCategory
            this.cmbSearchCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbSearchCategory.Font = new Font("Segoe UI", 10F);
            this.cmbSearchCategory.Location = new Point(110, 15);
            this.cmbSearchCategory.Name = "cmbSearchCategory";
            this.cmbSearchCategory.Size = new Size(200, 25);
            this.cmbSearchCategory.TabIndex = 1;
            
            // lblSearch
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.lblSearch.ForeColor = Color.FromArgb(71, 85, 105);
            this.lblSearch.Location = new Point(330, 18);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new Size(72, 19);
            this.lblSearch.TabIndex = 2;
            this.lblSearch.Text = "Keyword:";
            
            // txtSearch
            this.txtSearch.Font = new Font("Segoe UI", 10F);
            this.txtSearch.Location = new Point(410, 15);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new Size(300, 25);
            this.txtSearch.TabIndex = 3;
            
            // btnSearch
            this.btnSearch.BackColor = Color.FromArgb(52, 152, 219);
            this.btnSearch.FlatStyle = FlatStyle.Flat;
            this.btnSearch.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnSearch.ForeColor = Color.White;
            this.btnSearch.Location = new Point(730, 15);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new Size(100, 30);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            
            // btnRefresh
            this.btnRefresh.BackColor = Color.FromArgb(46, 204, 113);
            this.btnRefresh.FlatStyle = FlatStyle.Flat;
            this.btnRefresh.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnRefresh.ForeColor = Color.White;
            this.btnRefresh.Location = new Point(850, 15);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new Size(100, 30);
            this.btnRefresh.TabIndex = 5;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            
            this.panelSearch.Controls.Add(this.btnRefresh);
            this.panelSearch.Controls.Add(this.btnSearch);
            this.panelSearch.Controls.Add(this.txtSearch);
            this.panelSearch.Controls.Add(this.lblSearch);
            this.panelSearch.Controls.Add(this.cmbSearchCategory);
            this.panelSearch.Controls.Add(this.lblSearchBy);
            
            // dgvInventory
            this.dgvInventory.AllowUserToAddRows = false;
            this.dgvInventory.AllowUserToDeleteRows = false;
            this.dgvInventory.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            this.dgvInventory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvInventory.BackgroundColor = Color.White;
            this.dgvInventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Location = new Point(20, 184);
            this.dgvInventory.MultiSelect = false;
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.ReadOnly = true;
            this.dgvInventory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvInventory.Size = new Size(900, 450);
            this.dgvInventory.TabIndex = 3;
            this.dgvInventory.SelectionChanged += new System.EventHandler(this.dgvInventory_SelectionChanged);
            
            // panelButtons
            this.panelButtons.BackColor = Color.FromArgb(236, 240, 241);
            this.panelButtons.Dock = DockStyle.Bottom;
            this.panelButtons.Location = new Point(0, 655);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new Size(1400, 60);
            this.panelButtons.TabIndex = 4;
            
            // btnAdd
            this.btnAdd.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnAdd.Location = new Point(20, 12);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new Size(150, 36);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "+ Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            
            // btnEdit
            this.btnEdit.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnEdit.Location = new Point(190, 12);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new Size(150, 36);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            
            // btnDelete
            this.btnDelete.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnDelete.Location = new Point(360, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new Size(150, 36);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            
            // btnExport
            this.btnExport.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnExport.Location = new Point(530, 12);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new Size(150, 36);
            this.btnExport.TabIndex = 3;
            this.btnExport.Text = "Export";
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            
            this.panelButtons.Controls.Add(this.btnExport);
            this.panelButtons.Controls.Add(this.btnDelete);
            this.panelButtons.Controls.Add(this.btnEdit);
            this.panelButtons.Controls.Add(this.btnAdd);
            
            // panelDetails
            this.panelDetails.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            this.panelDetails.BackColor = Color.White;
            this.panelDetails.BorderStyle = BorderStyle.FixedSingle;
            this.panelDetails.Location = new Point(940, 184);
            this.panelDetails.Name = "panelDetails";
            this.panelDetails.Size = new Size(440, 450);
            this.panelDetails.TabIndex = 5;
            
            // lblItemDetails
            this.lblItemDetails.AutoSize = true;
            this.lblItemDetails.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblItemDetails.Location = new Point(15, 15);
            this.lblItemDetails.Name = "lblItemDetails";
            this.lblItemDetails.Size = new Size(120, 25);
            this.lblItemDetails.TabIndex = 0;
            this.lblItemDetails.Text = "Item Details";
            
            // lblItemID
            this.lblItemID.AutoSize = true;
            this.lblItemID.Location = new Point(40, 60);
            this.lblItemID.Name = "lblItemID";
            this.lblItemID.Size = new Size(50, 15);
            this.lblItemID.TabIndex = 1;
            this.lblItemID.Text = "Item ID:";
            
            // txtItemID
            this.txtItemID.Location = new Point(140, 57);
            this.txtItemID.Name = "txtItemID";
            this.txtItemID.ReadOnly = true;
            this.txtItemID.Size = new Size(280, 23);
            this.txtItemID.TabIndex = 2;
            
            // lblItemName
            this.lblItemName.AutoSize = true;
            this.lblItemName.Location = new Point(40, 95);
            this.lblItemName.Name = "lblItemName";
            this.lblItemName.Size = new Size(70, 15);
            this.lblItemName.TabIndex = 3;
            this.lblItemName.Text = "Item Name:";
            
            // txtItemName
            this.txtItemName.Location = new Point(140, 92);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new Size(280, 23);
            this.txtItemName.TabIndex = 4;
            
            // lblCategory
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new Point(40, 130);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new Size(58, 15);
            this.lblCategory.TabIndex = 5;
            this.lblCategory.Text = "Category:";
            
            // cmbCategory
            this.cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbCategory.Location = new Point(140, 127);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new Size(280, 23);
            this.cmbCategory.TabIndex = 6;
            
            // lblSize
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new Point(40, 165);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new Size(30, 15);
            this.lblSize.TabIndex = 7;
            this.lblSize.Text = "Size:";
            
            // cmbSize
            this.cmbSize.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbSize.Location = new Point(140, 162);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new Size(280, 23);
            this.cmbSize.TabIndex = 8;
            
            // lblColor
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new Point(40, 200);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new Size(39, 15);
            this.lblColor.TabIndex = 9;
            this.lblColor.Text = "Color:";
            
            // txtColor
            this.txtColor.Location = new Point(140, 197);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new Size(280, 23);
            this.txtColor.TabIndex = 10;
            
            // lblQuantity
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new Point(40, 235);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new Size(56, 15);
            this.lblQuantity.TabIndex = 11;
            this.lblQuantity.Text = "Quantity:";
            
            // nudQuantity
            this.nudQuantity.Location = new Point(140, 232);
            this.nudQuantity.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new Size(280, 23);
            this.nudQuantity.TabIndex = 12;
            
            // lblPrice
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new Point(40, 270);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new Size(75, 15);
            this.lblPrice.TabIndex = 13;
            this.lblPrice.Text = "Price (PHP):";
            
            // txtPrice
            this.txtPrice.Location = new Point(140, 267);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new Size(280, 23);
            this.txtPrice.TabIndex = 14;
            
            // lblSupplier
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Location = new Point(40, 305);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new Size(53, 15);
            this.lblSupplier.TabIndex = 15;
            this.lblSupplier.Text = "Supplier:";
            
            // txtSupplier
            this.txtSupplier.Location = new Point(140, 302);
            this.txtSupplier.Name = "txtSupplier";
            this.txtSupplier.Size = new Size(280, 23);
            this.txtSupplier.TabIndex = 16;
            
            // btnSave
            this.btnSave.Enabled = false;
            this.btnSave.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnSave.Location = new Point(220, 350);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(100, 36);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            
            // btnCancel
            this.btnCancel.Enabled = false;
            this.btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnCancel.Location = new Point(340, 350);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(100, 36);
            this.btnCancel.TabIndex = 18;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            
            this.panelDetails.Controls.Add(this.btnCancel);
            this.panelDetails.Controls.Add(this.btnSave);
            this.panelDetails.Controls.Add(this.txtSupplier);
            this.panelDetails.Controls.Add(this.lblSupplier);
            this.panelDetails.Controls.Add(this.txtPrice);
            this.panelDetails.Controls.Add(this.lblPrice);
            this.panelDetails.Controls.Add(this.nudQuantity);
            this.panelDetails.Controls.Add(this.lblQuantity);
            this.panelDetails.Controls.Add(this.txtColor);
            this.panelDetails.Controls.Add(this.lblColor);
            this.panelDetails.Controls.Add(this.cmbSize);
            this.panelDetails.Controls.Add(this.lblSize);
            this.panelDetails.Controls.Add(this.cmbCategory);
            this.panelDetails.Controls.Add(this.lblCategory);
            this.panelDetails.Controls.Add(this.txtItemName);
            this.panelDetails.Controls.Add(this.lblItemName);
            this.panelDetails.Controls.Add(this.txtItemID);
            this.panelDetails.Controls.Add(this.lblItemID);
            this.panelDetails.Controls.Add(this.lblItemDetails);
            
            // statusStrip1
            this.statusStrip1.Items.AddRange(new ToolStripItem[] { this.toolStripStatusLabel });
            this.statusStrip1.Location = new Point(0, 715);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(1400, 22);
            this.statusStrip1.TabIndex = 6;
            
            // toolStripStatusLabel
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new Size(39, 17);
            this.toolStripStatusLabel.Text = "Ready";
            
            // Form1
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(1400, 737);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panelDetails);
            this.Controls.Add(this.panelButtons);
            this.Controls.Add(this.dgvInventory);
            this.Controls.Add(this.panelSearch);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Kids Merch Inventory Management System";
            this.Load += new System.EventHandler(this.Form1_Load);
            
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private Panel panelTop;
        private Label lblTitle;
        private Panel panelSearch;
        private Button btnSearch;
        private TextBox txtSearch;
        private Label lblSearch;
        private ComboBox cmbSearchCategory;
        private Label lblSearchBy;
        private Button btnRefresh;
        private DataGridView dgvInventory;
        private Panel panelButtons;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnExport;
        private Panel panelDetails;
        private Label lblItemDetails;
        private Label lblItemID;
        private TextBox txtItemID;
        private Label lblItemName;
        private TextBox txtItemName;
        private Label lblCategory;
        private ComboBox cmbCategory;
        private Label lblSize;
        private ComboBox cmbSize;
        private Label lblColor;
        private TextBox txtColor;
        private Label lblQuantity;
        private NumericUpDown nudQuantity;
        private Label lblPrice;
        private TextBox txtPrice;
        private Label lblSupplier;
        private TextBox txtSupplier;
        private Button btnSave;
        private Button btnCancel;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem salesToolStripMenuItem;
        private ToolStripMenuItem newSaleToolStripMenuItem;
        private ToolStripMenuItem transactionHistoryToolStripMenuItem;
        private ToolStripMenuItem inventoryToolStripMenuItem;
        private ToolStripMenuItem archivedItemsToolStripMenuItem;
        private ToolStripMenuItem importExportToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem generateTestDataToolStripMenuItem;
        private ToolStripMenuItem generate10ItemsToolStripMenuItem;
        private ToolStripMenuItem generate50ItemsToolStripMenuItem;
        private ToolStripMenuItem generate100ItemsToolStripMenuItem;
        private ToolStripMenuItem clearAllDataToolStripMenuItem;
        private ToolStripMenuItem managementToolStripMenuItem;
        private ToolStripMenuItem userManagementToolStripMenuItem;
        private ToolStripMenuItem auditTrailToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem settingsToolStripMenuItem;
        private ToolStripMenuItem reportsToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
    }
}
