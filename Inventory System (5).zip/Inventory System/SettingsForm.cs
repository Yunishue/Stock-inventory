using System;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;
using System.Collections.Generic;

namespace KidsMerch
{
    public partial class SettingsForm : Form
    {
        private string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json");

        public SettingsForm()
        {
            InitializeComponent();
            LoadSettings();

            // initialize theme toggles
            // follow OS theme by default
            chkFollowOSTheme.Checked = true;
            chkUseDarkTheme.Checked = ThemeManager.CurrentThemeType == ThemeType.Dark;
        }

        private void LoadSettings()
        {
            if (!File.Exists(path)) return;
            try
            {
                var json = File.ReadAllText(path);
                var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("ConnectionStrings", out var cs) && cs.TryGetProperty("DefaultConnection", out var def))
                {
                    txtConnectionString.Text = def.GetString();
                }

                bool followOS = true;
                if (doc.RootElement.TryGetProperty("Theme", out var themeProp))
                {
                    var themeVal = themeProp.GetString();
                    if (string.Equals(themeVal, "Dark", StringComparison.OrdinalIgnoreCase)) ThemeManager.SetTheme(ThemeType.Dark);
                    else if (string.Equals(themeVal, "Light", StringComparison.OrdinalIgnoreCase)) ThemeManager.SetTheme(ThemeType.Light);
                    else if (string.Equals(themeVal, "FollowOS", StringComparison.OrdinalIgnoreCase))
                    {
                        followOS = true;
                        ThemeManager.SetTheme(ThemeManager.GetSystemTheme());
                    }
                }

                chkFollowOSTheme.Checked = followOS;
            }
            catch
            {
                lblStatus.Text = "Failed to read existing settings.";
                lblStatus.ForeColor = System.Drawing.Color.OrangeRed;
            }
        }

        private bool IsConnectionStringValidFormat(string conn)
        {
            if (string.IsNullOrWhiteSpace(conn)) return false;
            // Basic heuristic checks (not exhaustive)
            return conn.Contains("Server=", StringComparison.OrdinalIgnoreCase) || conn.Contains("Data Source=", StringComparison.OrdinalIgnoreCase);
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            var conn = txtConnectionString.Text.Trim();
            if (!IsConnectionStringValidFormat(conn))
            {
                lblStatus.Text = "Connection string format looks invalid.";
                lblStatus.ForeColor = System.Drawing.Color.OrangeRed;
                return;
            }
            try
            {
                using (var dm = new DatabaseManager(conn))
                {
                    if (dm.TestConnection())
                    {
                        lblStatus.Text = "Connection successful.";
                        lblStatus.ForeColor = System.Drawing.Color.ForestGreen;
                    }
                    else
                    {
                        lblStatus.Text = "Connection failed.";
                        lblStatus.ForeColor = System.Drawing.Color.OrangeRed;
                    }
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error: " + ex.Message;
                lblStatus.ForeColor = System.Drawing.Color.OrangeRed;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var conn = txtConnectionString.Text.Trim();
            if (!IsConnectionStringValidFormat(conn))
            {
                lblStatus.Text = "Please enter a valid SQL Server connection string.";
                lblStatus.ForeColor = System.Drawing.Color.OrangeRed;
                txtConnectionString.Focus();
                return;
            }

            string themeVal;
            if (chkFollowOSTheme.Checked) themeVal = "FollowOS";
            else themeVal = chkUseDarkTheme.Checked ? "Dark" : "Light";

            var root = new Dictionary<string, object>
            {
                ["ConnectionStrings"] = new Dictionary<string, string> { ["DefaultConnection"] = conn },
                ["Theme"] = themeVal
            };

            try
            {
                var json = JsonSerializer.Serialize(root, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(path, json);
                lblStatus.Text = "Saved. Restart application to apply (some UI updates may require restart).";
                lblStatus.ForeColor = System.Drawing.Color.ForestGreen;

                // apply theme immediately if not following OS
                if (chkFollowOSTheme.Checked)
                {
                    ThemeManager.SetTheme(ThemeManager.GetSystemTheme());
                }
                else
                {
                    ThemeManager.SetTheme(chkUseDarkTheme.Checked ? ThemeType.Dark : ThemeType.Light);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving settings: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void chkUseDarkTheme_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFollowOSTheme.Checked) return; // respect follow OS
            ThemeManager.SetTheme(chkUseDarkTheme.Checked ? ThemeType.Dark : ThemeType.Light);
        }

        private void chkFollowOSTheme_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFollowOSTheme.Checked)
            {
                ThemeManager.SetTheme(ThemeManager.GetSystemTheme());
            }
            else
            {
                ThemeManager.SetTheme(chkUseDarkTheme.Checked ? ThemeType.Dark : ThemeType.Light);
            }
        }
    }
}
