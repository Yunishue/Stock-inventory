using System;
using System.IO;

namespace KidsMerch
{
    internal static class Logger
    {
        private static readonly object lockObj = new object();
        private static string logPath;

        public static void Initialize(string path = null)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                var dir = AppDomain.CurrentDomain.BaseDirectory;
                logPath = Path.Combine(dir, "app.log");
            }
            else
            {
                logPath = path;
            }

            try
            {
                var dirName = Path.GetDirectoryName(logPath);
                if (!string.IsNullOrWhiteSpace(dirName)) Directory.CreateDirectory(dirName);
            }
            catch { }
        }

        public static void Info(string message)
        {
            Write("INFO", message);
        }

        public static void Error(string message)
        {
            Write("ERROR", message);
        }

        public static void Error(string message, Exception ex)
        {
            Write("ERROR", message + "\n" + ex);
        }

        private static void Write(string level, string message)
        {
            try
            {
                lock (lockObj)
                {
                    File.AppendAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {level}: {message}{Environment.NewLine}");
                }
            }
            catch
            {
                // best-effort logger
            }
        }
    }
}
