using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Text;

namespace KidsMerch
{
    // Additional behavior for SalesForm split into separate partial file so designer-generated SalesForm.cs doesn't need direct edits.
    public partial class SalesForm : Form
    {
        // Printing support used by extensions
        private PrintDocument _printDocumentExt;
        private string _receiptToPrintExt;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // Initialize print document (safe to do here even if original file also uses printing)
            if (_printDocumentExt == null)
            {
                _printDocumentExt = new PrintDocument();
                _printDocumentExt.PrintPage += PrintDocumentExt_PrintPage;
            }

            // Hook barcode textbox (designer adds txtBarcode); ignore if absent
            try
            {
                var tb = this.Controls.Find("txtBarcode", true).FirstOrDefault() as TextBox;
                if (tb != null)
                {
                    // Avoid double-hooking
                    tb.KeyDown -= TxtBarcode_KeyDown;
                    tb.KeyDown += TxtBarcode_KeyDown;
                }
            }
            catch
            {
                // ignore
            }
        }

        private void TxtBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            e.SuppressKeyPress = true;
            if (sender is not TextBox tb) return;
            var code = tb.Text?.Trim();
            if (string.IsNullOrEmpty(code)) return;

            ProcessBarcodeScan(code);
            tb.Clear();
        }

        private void ProcessBarcodeScan(string barcode)
        {
            try
            {
                DataTable dt = null;
                // Try helper on dbManager if available
                try { dt = dbManager.GetItemByBarcode(barcode); } catch { dt = null; }

                if (dt == null || dt.Rows.Count == 0)
                {
                    // Fallback query
                    string q = "SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price FROM ClothingInventory WHERE Barcode = @Barcode";
                    dt = dbManager.ExecuteQuery(q, new Dictionary<string, object> { { "@Barcode", barcode } });
                }

                if (dt == null || dt.Rows.Count == 0)
                {
                    MessageBox.Show($"No item found with barcode: {barcode}", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                var row = dt.Rows[0];
                int itemId = Convert.ToInt32(row["ItemID"]);
                int availableQty = Convert.ToInt32(row["Quantity"]);
                if (availableQty <= 0)
                {
                    MessageBox.Show("Item out of stock.", "Out of Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Add a single unit by default
                AddItemToCartById(itemId, 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error scanning barcode: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Small public wrapper used by other code paths (keeps name distinct from any existing methods)
        public void AddItemToCartById_Public(int itemId, int quantity) => AddItemToCartById(itemId, quantity);

        private void AddItemToCartById(int itemId, int quantity)
        {
            try
            {
                string query = "SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price FROM ClothingInventory WHERE ItemID = @ItemID";
                var parameters = new Dictionary<string, object> { { "@ItemID", itemId } };
                DataTable dt = dbManager.ExecuteQuery(query, parameters);
                if (dt == null || dt.Rows.Count == 0) return;

                var row = dt.Rows[0];
                int availableQty = Convert.ToInt32(row["Quantity"]);
                decimal price = Convert.ToDecimal(row["Price"]);

                var existingItem = currentTransaction.Items.FirstOrDefault(i => i.ItemID == itemId);
                int totalQtyInCart = existingItem?.Quantity ?? 0;
                if (totalQtyInCart + quantity > availableQty)
                {
                    MessageBox.Show($"Not enough stock! Available: {availableQty}, Already in cart: {totalQtyInCart}", "Insufficient Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (existingItem != null)
                {
                    existingItem.Quantity += quantity;
                    existingItem.CalculateSubtotal();
                }
                else
                {
                    var item = new SalesTransactionItem
                    {
                        ItemID = itemId,
                        ItemName = row["ItemName"].ToString(),
                        Category = row["Category"].ToString(),
                        Size = row["Size"].ToString(),
                        Color = row["Color"].ToString(),
                        Quantity = quantity,
                        UnitPrice = price
                    };
                    item.CalculateSubtotal();
                    currentTransaction.Items.Add(item);
                }

                RefreshCart();
                UpdateTotals();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding item by barcode: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Basic PrintDocument PrintPage handler used if external printing is invoked
        private void PrintDocumentExt_PrintPage(object sender, PrintPageEventArgs e)
        {
            if (string.IsNullOrEmpty(_receiptToPrintExt)) { e.HasMorePages = false; return; }

            using var font = new Font("Consolas", 10);
            float left = e.MarginBounds.Left;
            float top = e.MarginBounds.Top;
            float lineHeight = font.GetHeight(e.Graphics) + 2;
            var lines = _receiptToPrintExt.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            int linesPerPage = (int)(e.MarginBounds.Height / lineHeight);
            int count = 0;

            for (int i = 0; i < lines.Length; i++)
            {
                float y = top + count * lineHeight;
                e.Graphics.DrawString(lines[i], font, Brushes.Black, left, y);
                count++;
                if (count >= linesPerPage)
                {
                    e.HasMorePages = false; return;
                }
            }
            e.HasMorePages = false;
        }

        // Helper for other code to print using this extension (builds receipt and prints)
        public void PrintReceiptUsingPrinter(int transactionId)
        {
            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("=================================");
                sb.AppendLine("      KIDS MERCH STORE");
                sb.AppendLine("=================================");
                sb.AppendLine($"Receipt #: {transactionId}");
                sb.AppendLine($"Date: {currentTransaction.TransactionDate:MM/dd/yyyy HH:mm}");
                sb.AppendLine($"Customer: {currentTransaction.CustomerName}");
                sb.AppendLine("=================================");
                sb.AppendLine();

                foreach (var item in currentTransaction.Items)
                {
                    sb.AppendLine(item.ItemName);
                    sb.AppendLine($"  ({item.Size}, {item.Color})");
                    sb.AppendLine($"  {item.Quantity} x ?{item.UnitPrice:N2} = ?{item.Subtotal:N2}");
                    sb.AppendLine();
                }

                sb.AppendLine("=================================");
                sb.AppendLine($"TOTAL:        ?{currentTransaction.TotalAmount:N2}");
                sb.AppendLine($"PAYMENT:      ?{currentTransaction.AmountPaid:N2}");
                sb.AppendLine($"CHANGE:       ?{currentTransaction.Change:N2}");
                sb.AppendLine("=================================");
                sb.AppendLine($"Payment Method: {currentTransaction.PaymentMethod}");
                sb.AppendLine();
                sb.AppendLine("Thank you for your purchase!");
                sb.AppendLine("=================================");

                _receiptToPrintExt = sb.ToString();

                using var dlg = new PrintDialog();
                dlg.Document = _printDocumentExt;
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _printDocumentExt.Print();
                    dbManager.LogAudit(Session.CurrentUser?.UserID, "PrintReceipt", $"TransactionID={transactionId}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Printing error: {ex.Message}", "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
