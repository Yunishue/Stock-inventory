namespace KidsMerch
{
    partial class ResetPasswordDialog
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.btnSet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(12, 12);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.PlaceholderText = "New Password";
            this.txtNewPassword.Size = new System.Drawing.Size(260, 23);
            this.txtNewPassword.UseSystemPasswordChar = true;
            // 
            // btnSet
            // 
            this.btnSet.Location = new System.Drawing.Point(12, 44);
            this.btnSet.Size = new System.Drawing.Size(260, 30);
            this.btnSet.Text = "Set Password";
            this.btnSet.Click += new System.EventHandler(this.btnSet_Click);
            // 
            // ResetPasswordDialog
            // 
            this.ClientSize = new System.Drawing.Size(284, 86);
            this.Controls.Add(this.btnSet);
            this.Controls.Add(this.txtNewPassword);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Reset Password";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Button btnSet;
    }
}
