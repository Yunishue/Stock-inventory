using System;

namespace KidsMerch
{
    public class User
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public string FullName { get; set; }
    }
}
