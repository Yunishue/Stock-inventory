-- =====================================================
-- Test Data for Clothing Inventory System
-- =====================================================
-- Run this script after the database is created
-- to populate with sample test data
-- =====================================================

USE ClothingInventoryDB;
GO

-- Clear existing data (optional - for fresh testing)
-- DELETE FROM ClothingInventory;
-- GO

-- Insert 20 diverse test items
INSERT INTO ClothingInventory (ItemName, Category, Size, Color, Quantity, Price, Supplier)
VALUES 
    -- T-Shirts
    ('Classic White Tee', 'T-Shirt', 'M', 'White', 50, 19.99, 'Fashion Distributors Inc.'),
    ('V-Neck Black Tee', 'T-Shirt', 'L', 'Black', 35, 22.99, 'Urban Wear Co.'),
    ('Striped Cotton Tee', 'T-Shirt', 'S', 'Blue/White', 40, 24.99, 'Fashion Distributors Inc.'),
    
    -- Jeans
    ('Slim Fit Denim', 'Jeans', 'L', 'Blue', 30, 59.99, 'Denim World'),
    ('Distressed Jeans', 'Jeans', 'M', 'Light Blue', 25, 64.99, 'Denim World'),
    ('Black Skinny Jeans', 'Jeans', 'S', 'Black', 28, 54.99, 'Urban Wear Co.'),
    
    -- Dresses
    ('Summer Floral Dress', 'Dress', 'S', 'Floral', 25, 79.99, 'Elegant Wear Co.'),
    ('Evening Cocktail Dress', 'Dress', 'M', 'Red', 15, 129.99, 'Elegant Wear Co.'),
    ('Casual Maxi Dress', 'Dress', 'L', 'Navy', 20, 69.99, 'Summer Styles Ltd.'),
    
    -- Jackets
    ('Leather Jacket', 'Jacket', 'L', 'Black', 15, 199.99, 'Premium Outerwear'),
    ('Denim Jacket', 'Jacket', 'M', 'Blue', 22, 89.99, 'Denim World'),
    ('Bomber Jacket', 'Jacket', 'XL', 'Olive', 18, 109.99, 'Premium Outerwear'),
    
    -- Shorts
    ('Cargo Shorts', 'Shorts', 'M', 'Khaki', 40, 34.99, 'Summer Styles Ltd.'),
    ('Athletic Shorts', 'Shorts', 'L', 'Black', 45, 29.99, 'Athletic Footwear Inc.'),
    
    -- Sweaters
    ('Wool Crew Neck', 'Sweater', 'XL', 'Gray', 35, 69.99, 'Winter Warmth Co.'),
    ('Cable Knit Cardigan', 'Sweater', 'L', 'Cream', 28, 79.99, 'Winter Warmth Co.'),
    
    -- Pants
    ('Chino Pants', 'Pants', 'L', 'Beige', 32, 49.99, 'Outdoor Gear Suppliers'),
    ('Cargo Pants', 'Pants', 'XL', 'Olive Green', 28, 54.99, 'Outdoor Gear Suppliers'),
    
    -- Shoes
    ('Running Sneakers', 'Shoes', 'L', 'Black/White', 45, 89.99, 'Athletic Footwear Inc.'),
    ('Casual Loafers', 'Shoes', 'M', 'Brown', 30, 74.99, 'Elegant Wear Co.'),
    
    -- Accessories
    ('Leather Belt', 'Accessories', 'M', 'Brown', 60, 29.99, 'Accessories Plus'),
    ('Canvas Backpack', 'Accessories', 'L', 'Navy', 25, 49.99, 'Outdoor Gear Suppliers'),
    ('Baseball Cap', 'Accessories', 'M', 'Black', 75, 19.99, 'Urban Wear Co.'),
    ('Wool Scarf', 'Accessories', 'M', 'Gray', 40, 24.99, 'Winter Warmth Co.'),
    ('Sunglasses', 'Accessories', 'M', 'Black', 50, 39.99, 'Accessories Plus');

PRINT '25 test items inserted successfully!';
GO

-- Verification Query
SELECT 
    Category,
    COUNT(*) as ItemCount,
    AVG(Price) as AvgPrice,
    SUM(Quantity) as TotalQuantity
FROM ClothingInventory
GROUP BY Category
ORDER BY Category;
GO

PRINT '======================================';
PRINT 'Test Data Summary:';
PRINT '======================================';
SELECT 
    COUNT(*) as TotalItems,
    SUM(Quantity) as TotalPieces,
    MIN(Price) as MinPrice,
    MAX(Price) as MaxPrice,
    AVG(Price) as AvgPrice
FROM ClothingInventory;
GO
