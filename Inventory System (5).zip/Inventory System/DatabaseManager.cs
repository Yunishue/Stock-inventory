using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KidsMerch
{
    /// <summary>
    /// Database manager for SQL Server database
    /// </summary>
    public class DatabaseManager : IDisposable
    {
        private string connectionString;
        private bool disposed = false;

        public DatabaseManager(string connString)
        {
            if (!string.IsNullOrWhiteSpace(connString))
            {
                connectionString = connString;
                return;
            }

            // Prefer environment variables if provided; otherwise fall back to LocalDB
            var envConn = Environment.GetEnvironmentVariable("DB_CONNECTION");
            if (!string.IsNullOrWhiteSpace(envConn))
            {
                connectionString = envConn;
                return;
            }

            // Fall back to LocalDB
            var builder = new SqlConnectionStringBuilder();
            builder.DataSource = @"(localdb)\MSSQLLocalDB";
            builder.InitialCatalog = "KidsMerchDB";
            builder.IntegratedSecurity = true;
            connectionString = builder.ToString();
        }

        /// <summary>
        /// Test database connection
        /// </summary>
        public bool TestConnection()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Test database connection and return exception if any (null when success)
        /// </summary>
        public Exception TestConnectionDetailed()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return null;
                }
            }
            catch (Exception ex)
            {
                return ex;
            }
        }

        /// <summary>
        /// Initialize database (create database and tables if needed)
        /// </summary>
        public void InitializeDatabase()
        {
            // Ensure database exists if Initial Catalog provided
            var builder = new SqlConnectionStringBuilder(connectionString);
            string database = builder.InitialCatalog;

            if (!string.IsNullOrWhiteSpace(database))
            {
                // Create database if it doesn't exist
                string masterConn = connectionString.Replace($"Initial Catalog={database}", "Initial Catalog=master");
                using (SqlConnection conn = new SqlConnection(masterConn))
                {
                    conn.Open();
                    string checkDb = $"IF DB_ID(N'{database}') IS NULL CREATE DATABASE [{database}];";
                    using (SqlCommand cmd = new SqlCommand(checkDb, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Create tables if not exists
                string createInventory = @"
IF OBJECT_ID('dbo.ClothingInventory', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ClothingInventory (
        ItemID INT IDENTITY(1,1) PRIMARY KEY,
        ItemName NVARCHAR(200) NOT NULL,
        Category NVARCHAR(100) NOT NULL,
        Size NVARCHAR(50) NOT NULL,
        Color NVARCHAR(50) NOT NULL,
        Quantity INT NOT NULL,
        Price DECIMAL(18,2) NOT NULL,
        Supplier NVARCHAR(200) NOT NULL,
        Barcode NVARCHAR(100) NULL,
        DateAdded DATETIME DEFAULT GETDATE()
    );
END
";
                using (SqlCommand cmd = new SqlCommand(createInventory, conn)) cmd.ExecuteNonQuery();

                // Ensure IsDeleted column exists for soft-delete
                string addIsDeleted = @"
IF COL_LENGTH('dbo.ClothingInventory','IsDeleted') IS NULL
BEGIN
    ALTER TABLE dbo.ClothingInventory ADD IsDeleted BIT NOT NULL CONSTRAINT DF_ClothingInventory_IsDeleted DEFAULT (0);
END
";
                using (SqlCommand cmd = new SqlCommand(addIsDeleted, conn)) cmd.ExecuteNonQuery();

                string createTransactions = @"
IF OBJECT_ID('dbo.SalesTransactions', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SalesTransactions (
        TransactionID INT IDENTITY(1,1) PRIMARY KEY,
        TransactionDate DATETIME NOT NULL,
        CustomerName NVARCHAR(200),
        TotalAmount DECIMAL(18,2) NOT NULL,
        AmountPaid DECIMAL(18,2) NOT NULL,
        Change DECIMAL(18,2) NOT NULL,
        PaymentMethod NVARCHAR(50),
        Notes NVARCHAR(MAX)
    );
END
";
                using (SqlCommand cmd = new SqlCommand(createTransactions, conn)) cmd.ExecuteNonQuery();

                string createTransactionItems = @"
IF OBJECT_ID('dbo.SalesTransactionItems', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.SalesTransactionItems (
        TransactionItemID INT IDENTITY(1,1) PRIMARY KEY,
        TransactionID INT NOT NULL,
        ItemID INT NOT NULL,
        ItemName NVARCHAR(200) NOT NULL,
        Category NVARCHAR(100) NOT NULL,
        Size NVARCHAR(50) NOT NULL,
        Color NVARCHAR(50) NOT NULL,
        Quantity INT NOT NULL,
        UnitPrice DECIMAL(18,2) NOT NULL,
        Subtotal DECIMAL(18,2) NOT NULL,
        CONSTRAINT FK_STI_Transaction FOREIGN KEY (TransactionID) REFERENCES dbo.SalesTransactions(TransactionID),
        CONSTRAINT FK_STI_Item FOREIGN KEY (ItemID) REFERENCES dbo.ClothingInventory(ItemID)
    );
END
";
                using (SqlCommand cmd = new SqlCommand(createTransactionItems, conn)) cmd.ExecuteNonQuery();

                // Users table with salt and hash
                string createUsers = @"
IF OBJECT_ID('dbo.Users', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        UserID INT IDENTITY(1,1) PRIMARY KEY,
        Username NVARCHAR(100) NOT NULL UNIQUE,
        PasswordHash NVARCHAR(256) NOT NULL,
        PasswordSalt NVARCHAR(128) NOT NULL,
        Role NVARCHAR(50) NOT NULL,
        FullName NVARCHAR(200),
        CreatedAt DATETIME DEFAULT GETDATE()
    );
END
";
                using (SqlCommand cmd = new SqlCommand(createUsers, conn)) cmd.ExecuteNonQuery();

                // Audit table
                string createAudit = @"
IF OBJECT_ID('dbo.AuditTrail', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditTrail (
        AuditID INT IDENTITY(1,1) PRIMARY KEY,
        UserID INT NULL,
        Action NVARCHAR(200) NOT NULL,
        Details NVARCHAR(MAX),
        CreatedAt DATETIME DEFAULT GETDATE()
    );
END
";
                using (SqlCommand cmd = new SqlCommand(createAudit, conn)) cmd.ExecuteNonQuery();
            }
        }

        private void AddParameters(SqlCommand cmd, Dictionary<string, object> parameters)
        {
            if (parameters == null) return;
            foreach (var p in parameters)
            {
                var name = p.Key.StartsWith("@") ? p.Key : "@" + p.Key.TrimStart('@');
                var value = p.Value ?? DBNull.Value;

                SqlParameter param;
                if (value == DBNull.Value)
                {
                    param = new SqlParameter(name, SqlDbType.NVarChar) { Value = DBNull.Value };
                }
                else
                {
                    switch (Type.GetTypeCode(value.GetType()))
                    {
                        case TypeCode.Int32:
                        case TypeCode.Int16:
                        case TypeCode.Byte:
                            param = new SqlParameter(name, SqlDbType.Int) { Value = Convert.ToInt32(value) }; break;
                        case TypeCode.Decimal:
                        case TypeCode.Double:
                        case TypeCode.Single:
                            param = new SqlParameter(name, SqlDbType.Decimal) { Value = Convert.ToDecimal(value) }; break;
                        case TypeCode.DateTime:
                            param = new SqlParameter(name, SqlDbType.DateTime) { Value = Convert.ToDateTime(value) }; break;
                        case TypeCode.Boolean:
                            param = new SqlParameter(name, SqlDbType.Bit) { Value = Convert.ToBoolean(value) }; break;
                        default:
                            // treat as string
                            var s = value.ToString();
                            if (s.Length > 4000) param = new SqlParameter(name, SqlDbType.NVarChar, -1) { Value = s }; else param = new SqlParameter(name, SqlDbType.NVarChar, Math.Max(1, s.Length)) { Value = s };
                            break;
                    }
                }

                cmd.Parameters.Add(param);
            }
        }

        private string MaskParameterValue(string paramName, object value)
        {
            if (paramName == null) return "";
            var lower = paramName.ToLowerInvariant();
            if (lower.Contains("password") || lower.Contains("pwd") || lower.Contains("secret")) return "********";
            return value == null || value == DBNull.Value ? "NULL" : value.ToString();
        }

        private void LogCommand(string sql, Dictionary<string, object> parameters)
        {
            try
            {
                if (parameters == null || parameters.Count == 0)
                {
                    Logger.Info($"SQL: {sql}");
                }
                else
                {
                    var sb = new StringBuilder();
                    sb.AppendLine("SQL: " + sql);
                    sb.AppendLine("Parameters:");
                    foreach (var p in parameters)
                    {
                        sb.AppendLine($"  {p.Key} = {MaskParameterValue(p.Key, p.Value)}");
                    }
                    Logger.Info(sb.ToString());
                }
            }
            catch { }
        }

        /// <summary>
        /// Execute a query and return DataTable
        /// </summary>
        public DataTable ExecuteQuery(string query, Dictionary<string, object> parameters = null)
        {
            DataTable dt = new DataTable();
            try
            {
                LogCommand(query, parameters);
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        AddParameters(cmd, parameters);
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("ExecuteQuery failed", ex);
                throw;
            }
            return dt;
        }

        /// <summary>
        /// Execute a non-query command (INSERT, UPDATE, DELETE)
        /// </summary>
        public int ExecuteNonQuery(string query, Dictionary<string, object> parameters = null)
        {
            int rowsAffected = 0;
            try
            {
                LogCommand(query, parameters);
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        AddParameters(cmd, parameters);
                        rowsAffected = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("ExecuteNonQuery failed", ex);
                throw;
            }
            return rowsAffected;
        }

        /// <summary>
        /// Execute a scalar command and return single value
        /// </summary>
        public object ExecuteScalar(string query, Dictionary<string, object> parameters = null)
        {
            try
            {
                LogCommand(query, parameters);
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        AddParameters(cmd, parameters);
                        return cmd.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("ExecuteScalar failed", ex);
                throw;
            }
        }

        private static string GenerateSalt(int size = 16)
        {
            byte[] salt = new byte[size];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            return Convert.ToBase64String(salt);
        }

        private static string ComputeHash(string salt, string password)
        {
            // Use PBKDF2 with 10000 iterations
            var saltBytes = Convert.FromBase64String(salt);
            using (var derive = new Rfc2898DeriveBytes(password, saltBytes, 10000, HashAlgorithmName.SHA256))
            {
                var hash = derive.GetBytes(32);
                return Convert.ToBase64String(hash);
            }
        }

        /// <summary>
        /// Create user with raw password (salt+hash stored)
        /// </summary>
        public int CreateUser(string username, string rawPassword, string role, string fullName)
        {
            var salt = GenerateSalt(16);
            var hash = ComputeHash(salt, rawPassword);
            string query = @"INSERT INTO dbo.Users (Username, PasswordHash, PasswordSalt, Role, FullName) VALUES (@Username, @PasswordHash, @PasswordSalt, @Role, @FullName)";
            var parameters = new Dictionary<string, object>
            {
                { "@Username", username },
                { "@PasswordHash", hash },
                { "@PasswordSalt", salt },
                { "@Role", role },
                { "@FullName", fullName }
            };
            return ExecuteNonQuery(query, parameters);
        }

        /// <summary>
        /// Authenticate user by raw password
        /// </summary>
        public DataRow AuthenticateUser(string username, string rawPassword)
        {
            string query = @"SELECT UserID, Username, Role, FullName, PasswordHash, PasswordSalt FROM dbo.Users WHERE Username = @Username";
            var parameters = new Dictionary<string, object> { { "@Username", username } };
            DataTable dt = ExecuteQuery(query, parameters);
            if (dt.Rows.Count == 0) return null;
            var row = dt.Rows[0];
            string storedHash = row["PasswordHash"].ToString();
            string storedSalt = row["PasswordSalt"].ToString();
            var computed = ComputeHash(storedSalt, rawPassword);
            if (computed == storedHash)
            {
                // return only public columns
                var publicTable = dt.Clone();
                publicTable.Columns.Remove("PasswordHash");
                publicTable.Columns.Remove("PasswordSalt");
                var publicRow = publicTable.NewRow();
                publicRow["UserID"] = row["UserID"];
                publicRow["Username"] = row["Username"];
                publicRow["Role"] = row["Role"];
                publicRow["FullName"] = row["FullName"];
                publicTable.Rows.Add(publicRow);
                return publicTable.Rows[0];
            }
            return null;
        }

        public int ResetPassword(int userId, string newRawPassword)
        {
            var salt = GenerateSalt(16);
            var hash = ComputeHash(salt, newRawPassword);
            string query = @"UPDATE dbo.Users SET PasswordHash = @PasswordHash, PasswordSalt = @PasswordSalt WHERE UserID = @UserID";
            var parameters = new Dictionary<string, object>
            {
                { "@PasswordHash", hash },
                { "@PasswordSalt", salt },
                { "@UserID", userId }
            };
            return ExecuteNonQuery(query, parameters);
        }

        public DataTable GetUsers()
        {
            string query = @"SELECT UserID, Username, Role, FullName, CreatedAt FROM dbo.Users ORDER BY Username";
            return ExecuteQuery(query);
        }

        public DataTable GetAuditEntries(int top = 500)
        {
            string query = @"SELECT TOP (@Top) AuditID, UserID, Action, Details, CreatedAt FROM dbo.AuditTrail ORDER BY CreatedAt DESC";
            var parameters = new Dictionary<string, object> { { "@Top", top } };
            return ExecuteQuery(query, parameters);
        }

        public void LogAudit(int? userId, string action, string details)
        {
            string query = @"INSERT INTO dbo.AuditTrail (UserID, Action, Details) VALUES (@UserID, @Action, @Details)";
            var parameters = new Dictionary<string, object>
            {
                { "@UserID", userId.HasValue ? (object)userId.Value : DBNull.Value },
                { "@Action", action },
                { "@Details", details }
            };
            ExecuteNonQuery(query, parameters);
        }

        public string GetDatabaseType()
        {
            return "SQLServer";
        }

        public string GetConnectionString()
        {
            return connectionString;
        }

        /// <summary>
        /// Dispose of resources
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Clean up managed resources if needed
                }
                disposed = true;
            }
        }

        ~DatabaseManager()
        {
            Dispose(false);
        }

        public int SaveSalesTransaction(SalesTransaction transaction)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlTransaction dbTransaction = conn.BeginTransaction())
                {
                    try
                    {
                        string insertTransaction = @"INSERT INTO dbo.SalesTransactions (TransactionDate, CustomerName, TotalAmount, AmountPaid, Change, PaymentMethod, Notes)
VALUES (@TransactionDate, @CustomerName, @TotalAmount, @AmountPaid, @Change, @PaymentMethod, @Notes); SELECT SCOPE_IDENTITY();";
                        using (SqlCommand cmd = new SqlCommand(insertTransaction, conn, dbTransaction))
                        {
                            cmd.Parameters.AddWithValue("@TransactionDate", transaction.TransactionDate);
                            cmd.Parameters.AddWithValue("@CustomerName", transaction.CustomerName ?? "Walk-in Customer");
                            cmd.Parameters.AddWithValue("@TotalAmount", transaction.TotalAmount);
                            cmd.Parameters.AddWithValue("@AmountPaid", transaction.AmountPaid);
                            cmd.Parameters.AddWithValue("@Change", transaction.Change);
                            cmd.Parameters.AddWithValue("@PaymentMethod", transaction.PaymentMethod ?? "Cash");
                            cmd.Parameters.AddWithValue("@Notes", transaction.Notes ?? (object)DBNull.Value);

                            int transactionId = Convert.ToInt32(cmd.ExecuteScalar());

                            // Insert items
                            foreach (var item in transaction.Items)
                            {
                                string insertItem = @"INSERT INTO dbo.SalesTransactionItems (TransactionID, ItemID, ItemName, Category, Size, Color, Quantity, UnitPrice, Subtotal)
VALUES (@TransactionID, @ItemID, @ItemName, @Category, @Size, @Color, @Quantity, @UnitPrice, @Subtotal);";
                                using (SqlCommand cmdItem = new SqlCommand(insertItem, conn, dbTransaction))
                                {
                                    cmdItem.Parameters.AddWithValue("@TransactionID", transactionId);
                                    cmdItem.Parameters.AddWithValue("@ItemID", item.ItemID);
                                    cmdItem.Parameters.AddWithValue("@ItemName", item.ItemName);
                                    cmdItem.Parameters.AddWithValue("@Category", item.Category);
                                    cmdItem.Parameters.AddWithValue("@Size", item.Size);
                                    cmdItem.Parameters.AddWithValue("@Color", item.Color);
                                    cmdItem.Parameters.AddWithValue("@Quantity", item.Quantity);
                                    cmdItem.Parameters.AddWithValue("@UnitPrice", item.UnitPrice);
                                    cmdItem.Parameters.AddWithValue("@Subtotal", item.Subtotal);
                                    cmdItem.ExecuteNonQuery();
                                }

                                // Update inventory
                                string updateInventory = @"UPDATE dbo.ClothingInventory SET Quantity = Quantity - @Quantity WHERE ItemID = @ItemID";
                                using (SqlCommand cmdUp = new SqlCommand(updateInventory, conn, dbTransaction))
                                {
                                    cmdUp.Parameters.AddWithValue("@Quantity", item.Quantity);
                                    cmdUp.Parameters.AddWithValue("@ItemID", item.ItemID);
                                    cmdUp.ExecuteNonQuery();
                                }
                            }

                            dbTransaction.Commit();
                            return transactionId;
                        }
                    }
                    catch
                    {
                        dbTransaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public DataTable GetSalesTransactions(DateTime? startDate = null, DateTime? endDate = null)
        {
            string query = @"SELECT TransactionID, TransactionDate, CustomerName, TotalAmount, AmountPaid, Change, PaymentMethod, Notes FROM dbo.SalesTransactions";
            var parameters = new Dictionary<string, object>();
            if (startDate.HasValue && endDate.HasValue)
            {
                query += " WHERE TransactionDate BETWEEN @StartDate AND @EndDate";
                parameters.Add("@StartDate", startDate.Value);
                parameters.Add("@EndDate", endDate.Value);
            }
            query += " ORDER BY TransactionDate DESC";
            return ExecuteQuery(query, parameters.Count == 0 ? null : parameters);
        }

        public DataTable GetTransactionItems(int transactionId)
        {
            string query = @"SELECT TransactionItemID, ItemName, Category, Size, Color, Quantity, UnitPrice, Subtotal FROM dbo.SalesTransactionItems WHERE TransactionID = @TransactionID";
            var parameters = new Dictionary<string, object> { { "@TransactionID", transactionId } };
            return ExecuteQuery(query, parameters);
        }

        public DataTable GetSalesSummary(DateTime startDate, DateTime endDate)
        {
            string query = @"SELECT CONVERT(date, TransactionDate) as SalesDate, COUNT(*) as TransactionCount, SUM(TotalAmount) as TotalSales, AVG(TotalAmount) as AverageSale FROM dbo.SalesTransactions WHERE TransactionDate BETWEEN @StartDate AND @EndDate GROUP BY CONVERT(date, TransactionDate) ORDER BY SalesDate DESC";
            var parameters = new Dictionary<string, object>
            {
                { "@StartDate", startDate },
                { "@EndDate", endDate }
            };
            return ExecuteQuery(query, parameters);
        }

        public DataTable GetBestSellingItems(DateTime? startDate = null, DateTime? endDate = null, int topN = 10)
        {
            string query = @"SELECT TOP (@TopN) ItemName, Category, Size, Color, SUM(Quantity) as TotalSold, SUM(Subtotal) as TotalRevenue, AVG(UnitPrice) as AveragePrice FROM dbo.SalesTransactionItems sti JOIN dbo.SalesTransactions st ON sti.TransactionID = st.TransactionID";
            var parameters = new Dictionary<string, object> { { "@TopN", topN } };
            if (startDate.HasValue && endDate.HasValue)
            {
                query += " WHERE st.TransactionDate BETWEEN @StartDate AND @EndDate";
                parameters.Add("@StartDate", startDate.Value);
                parameters.Add("@EndDate", endDate.Value);
            }
            query += " GROUP BY ItemName, Category, Size, Color ORDER BY TotalSold DESC";
            return ExecuteQuery(query, parameters);
        }

        public DataTable GetSalesByCategory(DateTime? startDate = null, DateTime? endDate = null)
        {
            string query = @"SELECT Category, SUM(Quantity) as ItemsSold, SUM(Subtotal) as TotalRevenue, COUNT(DISTINCT sti.TransactionID) as TransactionCount FROM dbo.SalesTransactionItems sti JOIN dbo.SalesTransactions st ON sti.TransactionID = st.TransactionID";
            var parameters = new Dictionary<string, object>();
            if (startDate.HasValue && endDate.HasValue)
            {
                query += " WHERE st.TransactionDate BETWEEN @StartDate AND @EndDate";
                parameters.Add("@StartDate", startDate.Value);
                parameters.Add("@EndDate", endDate.Value);
            }
            query += " GROUP BY Category ORDER BY TotalRevenue DESC";
            return ExecuteQuery(query, parameters.Count == 0 ? null : parameters);
        }

        public DataTable GetItemByBarcode(string barcode)
        {
            string query = @"SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price, Supplier, Barcode FROM dbo.ClothingInventory WHERE Barcode = @Barcode AND IsDeleted = 0";
            var parameters = new Dictionary<string, object> { { "@Barcode", barcode } };
            return ExecuteQuery(query, parameters);
        }

        /// <summary>
        /// Execute multiple non-query commands inside a single transaction
        /// </summary>
        public int ExecuteNonQueryTransaction(List<(string Query, Dictionary<string, object> Parameters)> commands)
        {
            if (commands == null || commands.Count == 0) return 0;
            int totalAffected = 0;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlTransaction tx = conn.BeginTransaction())
                {
                    try
                    {
                        foreach (var cmdInfo in commands)
                        {
                            using (SqlCommand cmd = new SqlCommand(cmdInfo.Query, conn, tx))
                            {
                                AddParameters(cmd, cmdInfo.Parameters);
                                totalAffected += cmd.ExecuteNonQuery();
                            }
                        }

                        tx.Commit();
                        return totalAffected;
                    }
                    catch
                    {
                        try { tx.Rollback(); } catch { }
                        throw;
                    }
                }
            }
        }

        public async Task<DataTable> ExecuteQueryAsync(string query, Dictionary<string, object> parameters = null)
        {
            var dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                await conn.OpenAsync().ConfigureAwait(false);
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    AddParameters(cmd, parameters);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        // SqlDataAdapter has no async Fill, so use ExecuteReaderAsync
                        using (var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false))
                        {
                            dt.Load(reader);
                        }
                    }
                }
            }
            return dt;
        }

        public async Task<int> ExecuteNonQueryAsync(string query, Dictionary<string, object> parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                await conn.OpenAsync().ConfigureAwait(false);
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    AddParameters(cmd, parameters);
                    return await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
                }
            }
        }

        public async Task<object> ExecuteScalarAsync(string query, Dictionary<string, object> parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                await conn.OpenAsync().ConfigureAwait(false);
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    AddParameters(cmd, parameters);
                    return await cmd.ExecuteScalarAsync().ConfigureAwait(false);
                }
            }
        }

        public async Task<int> ExecuteNonQueryTransactionAsync(List<(string Query, Dictionary<string, object> Parameters)> commands)
        {
            if (commands == null || commands.Count == 0) return 0;
            int totalAffected = 0;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                await conn.OpenAsync().ConfigureAwait(false);
                using (SqlTransaction tx = conn.BeginTransaction())
                {
                    try
                    {
                        foreach (var cmdInfo in commands)
                        {
                            using (SqlCommand cmd = new SqlCommand(cmdInfo.Query, conn, tx))
                            {
                                AddParameters(cmd, cmdInfo.Parameters);
                                totalAffected += await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
                            }
                        }
                        tx.Commit();
                        return totalAffected;
                    }
                    catch
                    {
                        try { tx.Rollback(); } catch { }
                        throw;
                    }
                }
            }
        }
    }
}
