-- =====================================================
-- Clothing Inventory Database Setup Script
-- =====================================================
-- This script creates the database and table structure
-- Note: The application auto-creates these, but this 
-- script is provided for manual setup or documentation
-- =====================================================

USE master;
GO

-- Create Database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'ClothingInventoryDB')
BEGIN
    CREATE DATABASE ClothingInventoryDB;
    PRINT 'Database ClothingInventoryDB created successfully.';
END
ELSE
BEGIN
    PRINT 'Database ClothingInventoryDB already exists.';
END
GO

USE ClothingInventoryDB;
GO

-- Create ClothingInventory Table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ClothingInventory' AND xtype='U')
BEGIN
    CREATE TABLE ClothingInventory (
        ItemID INT PRIMARY KEY IDENTITY(1,1),
        ItemName NVARCHAR(100) NOT NULL,
        Category NVARCHAR(50) NOT NULL,
        Size NVARCHAR(10) NOT NULL,
        Color NVARCHAR(50) NOT NULL,
        Quantity INT NOT NULL CHECK (Quantity >= 0),
        Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
        Supplier NVARCHAR(100) NOT NULL,
        DateAdded DATETIME DEFAULT GETDATE() NOT NULL
    );
    PRINT 'Table ClothingInventory created successfully.';
END
ELSE
BEGIN
    PRINT 'Table ClothingInventory already exists.';
END
GO

-- Create Index for better search performance
CREATE NONCLUSTERED INDEX IX_ClothingInventory_ItemName 
ON ClothingInventory(ItemName);
GO

CREATE NONCLUSTERED INDEX IX_ClothingInventory_Category 
ON ClothingInventory(Category);
GO

CREATE NONCLUSTERED INDEX IX_ClothingInventory_Supplier 
ON ClothingInventory(Supplier);
GO

PRINT 'Indexes created successfully.';
GO

-- =====================================================
-- Sample Data (Optional - for testing)
-- =====================================================
-- Uncomment the following section to insert sample data

/*
INSERT INTO ClothingInventory (ItemName, Category, Size, Color, Quantity, Price, Supplier)
VALUES 
    ('Classic Cotton T-Shirt', 'T-Shirt', 'M', 'White', 50, 19.99, 'Fashion Distributors Inc.'),
    ('Slim Fit Jeans', 'Jeans', 'L', 'Blue', 30, 59.99, 'Denim World'),
    ('Summer Dress', 'Dress', 'S', 'Floral', 25, 79.99, 'Elegant Wear Co.'),
    ('Leather Jacket', 'Jacket', 'L', 'Black', 15, 199.99, 'Premium Outerwear'),
    ('Casual Shorts', 'Shorts', 'M', 'Khaki', 40, 34.99, 'Summer Styles Ltd.'),
    ('Pleated Skirt', 'Skirt', 'M', 'Navy Blue', 20, 44.99, 'Fashion Distributors Inc.'),
    ('Wool Sweater', 'Sweater', 'XL', 'Gray', 35, 69.99, 'Winter Warmth Co.'),
    ('Cargo Pants', 'Pants', 'L', 'Olive Green', 28, 54.99, 'Outdoor Gear Suppliers'),
    ('Running Shoes', 'Shoes', 'L', 'Black/White', 45, 89.99, 'Athletic Footwear Inc.'),
    ('Designer Belt', 'Accessories', 'M', 'Brown', 60, 29.99, 'Accessories Plus');

PRINT 'Sample data inserted successfully.';
*/
GO

-- =====================================================
-- Verification Query
-- =====================================================
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ClothingInventory'
ORDER BY ORDINAL_POSITION;
GO

PRINT '=====================================================';
PRINT 'Database setup complete!';
PRINT 'You can now run the Clothing Inventory application.';
PRINT '=====================================================';
GO
