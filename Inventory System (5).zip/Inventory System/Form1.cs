using System;
using System.Data;
using System.Linq;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;

namespace KidsMerch
{
    public partial class Form1 : Form
    {
        private DatabaseManager dbManager;
        private bool isAddMode = false;
        private bool isEditMode = false;
        private readonly CultureInfo filipinoCulture = new CultureInfo("en-PH");

        // Loading / cancellation UI
        private Panel loadingOverlay;
        private Label loadingLabel;
        private ProgressBar loadingProgressBar;
        private Label loadingPercentLabel;
        private Button loadingCancelButton;
        private CancellationTokenSource loadingCts;

        // ErrorProvider for inline validation
        private ErrorProvider inputErrorProvider;

        // Size presets
        private readonly string[] predefinedClothingSizes = new[] { "XS", "S", "M", "L", "XL", "XXL", "XXXL" };
        private readonly string[] predefinedShoeSizes = new[] { "4", "5", "6", "7", "8", "9", "10", "11", "12", "13" };

        public Form1(DatabaseManager db)
        {
            InitializeComponent();
            this.dbManager = db ?? throw new ArgumentNullException(nameof(db));

            // setup inline error provider
            inputErrorProvider = new ErrorProvider();
            inputErrorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;
            inputErrorProvider.ContainerControl = this;
        }

        /// <summary>
        /// Configure responsive layout that designer cannot generate
        /// </summary>
        private void ConfigureDynamicLayout()
        {
            // Nothing needed here now - designer handles all layout
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                RebuildMainMenu(); // setup menu
                await LoadInventoryDataAsync();

                // populate category/size comboboxes from distinct values
                var catDt = await dbManager.ExecuteQueryAsync("SELECT DISTINCT Category FROM dbo.ClothingInventory ORDER BY Category");
                cmbCategory.Items.Clear();
                cmbSearchCategory.Items.Clear();
                cmbSearchCategory.Items.Add("All");
                cmbSearchCategory.SelectedIndex = 0;
                foreach (DataRow r in catDt.Rows)
                {
                    var v = r[0]?.ToString();
                    if (!string.IsNullOrWhiteSpace(v))
                    {
                        cmbCategory.Items.Add(v);
                        cmbSearchCategory.Items.Add(v);
                    }
                }

                // Wire category change to populate sizes appropriate for the category
                cmbSize.Items.Clear();
                cmbCategory.SelectedIndexChanged -= CmbCategory_SelectedIndexChanged;
                cmbCategory.SelectedIndexChanged += CmbCategory_SelectedIndexChanged;

                // If a category is already selected, trigger population
                if (cmbCategory.SelectedIndex >= 0) _ = Task.Run(() => this.InvokeIfRequired(() => CmbCategory_SelectedIndexChanged(this, EventArgs.Empty)));

                ApplyRolePermissions();

                // Apply global theme and typography
                // Defer theme application until after initial layout completes to avoid control jumps
                this.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        ThemeManager.PreserveLayoutOnThemeApply = true;
                        ThemeManager.ApplyTheme(this);
                    }
                    catch { }
                }));

                UpdateStatusLabel("Ready");

                // Center inner details table
                CenterDetailsPanel();
                this.Resize += (s, ev) => CenterDetailsPanel();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load inventory: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AdjustDetailPanelWidth()
        {
            // No-op: layout handled by anchors/docking
        }

        private void CenterDetailsPanel()
        {
            try
            {
                var tblDetails = panelDetails?.Controls.OfType<TableLayoutPanel>().FirstOrDefault(t => t.Name == "tblDetails");
                if (tblDetails == null) return;
                int panelInnerWidth = panelDetails.ClientSize.Width;
                int tableWidth = tblDetails.Width;
                int newLeft = Math.Max(12, (panelInnerWidth - tableWidth) / 2);
                tblDetails.Left = newLeft;
            }
            catch { }
        }

        private void EnsureLoadingOverlay()
        {
            if (loadingOverlay != null) return;
            loadingOverlay = new Panel
            {
                BackColor = Color.FromArgb(160, Color.Black),
                Visible = false,
                Name = "loadingOverlay"
            };

            loadingLabel = new Label
            {
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Dock = DockStyle.None
            };

            loadingProgressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Width = 300, Height = 18, Minimum = 0, Maximum = 100 };
            loadingPercentLabel = new Label { AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 9F), Text = "0%" };
            loadingCancelButton = new Button { Text = "Cancel", AutoSize = true };
            loadingCancelButton.Click += (s, e) => { try { loadingCts?.Cancel(); } catch { } };

            loadingOverlay.Controls.Add(loadingProgressBar);
            loadingOverlay.Controls.Add(loadingPercentLabel);
            loadingOverlay.Controls.Add(loadingLabel);
            loadingOverlay.Controls.Add(loadingCancelButton);
            this.Controls.Add(loadingOverlay);
            loadingOverlay.BringToFront();

            this.Resize += (s, e) => LayoutLoadingOverlay();
            LayoutLoadingOverlay();
        }

        private void LayoutLoadingOverlay()
        {
            if (loadingOverlay == null) return;
            loadingOverlay.Left = 0; loadingOverlay.Top = 0;
            loadingOverlay.Width = this.ClientSize.Width; loadingOverlay.Height = this.ClientSize.Height;

            foreach (Control c in loadingOverlay.Controls)
            {
                c.Left = (loadingOverlay.Width - c.Width) / 2;
            }

            if (loadingOverlay.Controls.Count >= 4)
            {
                var progress = loadingOverlay.Controls[0];
                var pct = loadingOverlay.Controls[1];
                var lbl = loadingOverlay.Controls[2];
                var btn = loadingOverlay.Controls[3];

                progress.Top = (loadingOverlay.Height / 2) - 30;
                pct.Top = progress.Bottom + 6;
                lbl.Top = pct.Bottom + 8; lbl.Width = loadingOverlay.Width; lbl.Left = 0;
                btn.Top = lbl.Bottom + 8;
            }
        }

        private void ShowLoading(string message = "Loading...", bool cancellable = false)
        {
            try
            {
                EnsureLoadingOverlay();
                loadingLabel.Text = message;
                loadingProgressBar.Value = 0; loadingPercentLabel.Text = "0%";
                loadingCancelButton.Visible = cancellable;
                LayoutLoadingOverlay();
                loadingOverlay.Visible = true; loadingOverlay.BringToFront();
            }
            catch { }
        }

        private void HideLoading()
        {
            try { if (loadingOverlay != null) loadingOverlay.Visible = false; loadingCts?.Dispose(); loadingCts = null; } catch { }
        }

        private async Task StartCancelableOperation(Func<IProgress<int>, CancellationToken, Task> operation, string message = "Working...")
        {
            try { loadingCts?.Cancel(); } catch { }
            loadingCts = new CancellationTokenSource(); var token = loadingCts.Token;
            var progress = new Progress<int>(p => { try { loadingProgressBar.Value = Math.Max(0, Math.Min(100, p)); loadingPercentLabel.Text = $"{loadingProgressBar.Value}%"; } catch { } });
            ShowLoading(message, cancellable: true);
            try { await operation(progress, token).ConfigureAwait(false); }
            catch (OperationCanceledException) { this.InvokeIfRequired(() => UpdateStatusLabel("Operation cancelled", StatusType.Warning)); }
            catch (Exception ex) { this.InvokeIfRequired(() => { MessageBox.Show($"Operation failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); UpdateStatusLabel($"Operation failed: {ex.Message}", StatusType.Error); }); }
            finally { this.InvokeIfRequired(() => HideLoading()); }
        }

        private async Task LoadInventoryDataAsync(string searchBy = "All", string keyword = "")
        {
            await StartCancelableOperation(async (progress, token) =>
            {
                progress.Report(5);
                try
                {
                    string query = "SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price, Supplier, DateAdded FROM dbo.ClothingInventory WHERE IsDeleted = 0";
                    var whereClauses = new List<string>();
                    Dictionary<string, object> parameters = new Dictionary<string, object>();

                    if (!string.IsNullOrWhiteSpace(searchBy) && searchBy != "All") { whereClauses.Add("Category = @CategoryFilter"); parameters.Add("@CategoryFilter", searchBy); }
                    if (!string.IsNullOrWhiteSpace(keyword)) { whereClauses.Add("(ItemName LIKE @keyword OR Category LIKE @keyword OR Color LIKE @keyword OR Supplier LIKE @keyword)"); parameters["@keyword"] = "%" + keyword + "%"; }
                    if (whereClauses.Any()) query += " AND " + string.Join(" AND ", whereClauses);

                    progress.Report(20);
                    DataTable dt = await Task.Run(async () => await dbManager.ExecuteQueryAsync(query, parameters.Count == 0 ? null : parameters), token);
                    progress.Report(70);

                    this.InvokeIfRequired(() =>
                    {
                        dgvInventory.DataSource = dt;
                        if (dgvInventory.Columns.Contains("Price")) { dgvInventory.Columns["Price"].DefaultCellStyle.Format = "N2"; dgvInventory.Columns["Price"].DefaultCellStyle.FormatProvider = filipinoCulture; dgvInventory.Columns["Price"].HeaderText = "Price (PHP)"; }
                        if (dgvInventory.Columns.Contains("DateAdded")) dgvInventory.Columns["DateAdded"].DefaultCellStyle.Format = "MM/dd/yyyy";
                        CheckLowStockItems(dt);
                        UpdateStatusLabel($"Loaded {dt.Rows.Count} item(s)");
                    });

                    progress.Report(100);
                }
                catch (Exception) { throw; }
            }, "Loading inventory...");
        }

        private void CheckLowStockItems(DataTable dt)
        {
            try
            {
                var lowStockItems = dt.AsEnumerable().Where(row => Convert.ToInt32(row["Quantity"]) < 10).Select(row => row["ItemName"].ToString()).ToList();
                if (lowStockItems.Any())
                {
                    UpdateStatusLabel($"{lowStockItems.Count} low stock item(s)", StatusType.Warning);
                    if (lowStockItems.Count <= 5)
                    {
                        string items = string.Join("\n� ", lowStockItems);
                        MessageBox.Show($"The following items are low in stock (less than 10 units):\n\n� {items}", "Low Stock Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch { }
        }

        #region Button Event Handlers

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            string searchBy = cmbSearchCategory.SelectedItem?.ToString() ?? "All";
            string keyword = txtSearch.Text.Trim();
            if (keyword == "Type to search...") keyword = string.Empty;
            await LoadInventoryDataAsync(searchBy, keyword);
        }

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear(); cmbSearchCategory.SelectedIndex = 0; await LoadInventoryDataAsync();
        }

        private void btnAdd_Click(object sender, EventArgs e) { SetFormMode("add"); ClearInputFields(); }
        private void btnEdit_Click(object sender, EventArgs e) { if (dgvInventory.SelectedRows.Count > 0) { SetFormMode("edit"); PopulateInputFields(); } else MessageBox.Show("Please select an item to edit.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning); }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvInventory.SelectedRows.Count == 0) { MessageBox.Show("Please select an item to archive.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            DialogResult result = ConfirmDialog.Show(this, "Are you sure you want to archive this item? You can restore it from Archived Items.", "Confirm Archive", MessageBoxButtons.YesNo);
            if (result != DialogResult.Yes) return;

            ShowLoading("Archiving item...");
            try
            {
                int itemId = Convert.ToInt32(dgvInventory.SelectedRows[0].Cells["ItemID"].Value);
                string checkQuery = "SELECT COUNT(1) FROM dbo.SalesTransactionItems WHERE ItemID = @ItemID";
                var dtCheck = await dbManager.ExecuteQueryAsync(checkQuery, new Dictionary<string, object> { { "@ItemID", itemId } });
                int dependentCount = dtCheck.Rows.Count > 0 ? Convert.ToInt32(dtCheck.Rows[0][0]) : 0;

                if (dependentCount > 0)
                {
                    var prompt = $"This item is referenced by {dependentCount} sold item record(s). Archiving it will remove related sales item entries and may remove transactions that become empty.\n\nDo you want to also archive related sales data?";
                    var cascade = ConfirmDialog.Show(this, prompt, "Dependent Data Found", MessageBoxButtons.YesNoCancel);
                    if (cascade == DialogResult.Cancel) return;
                    if (cascade == DialogResult.Yes)
                    {
                        var commands = new List<(string Query, Dictionary<string, object> Parameters)>
                        {
                            ("DELETE FROM dbo.SalesTransactionItems WHERE ItemID = @ItemID", new Dictionary<string, object> { { "@ItemID", itemId } }),
                            ("DELETE FROM dbo.SalesTransactions WHERE TransactionID NOT IN (SELECT DISTINCT TransactionID FROM dbo.SalesTransactionItems)", null),
                            ("UPDATE dbo.ClothingInventory SET IsDeleted = 1 WHERE ItemID = @ItemID", new Dictionary<string, object> { { "@ItemID", itemId } })
                        };
                        await dbManager.ExecuteNonQueryTransactionAsync(commands);
                        dbManager.LogAudit(Session.CurrentUser?.UserID, "DeleteItemCascade", $"ItemID={itemId}");
                        Toast.Show(this, "Item and related sales data archived successfully! You can restore them from Archived Items.", Toast.ToastType.Success);
                        await LoadInventoryDataAsync(); ClearInputFields(); return;
                    }
                    Toast.Show(this, "Archiving cancelled. Remove related sales records first to archive this item.", Toast.ToastType.Info); return;
                }

                await dbManager.ExecuteNonQueryAsync("UPDATE dbo.ClothingInventory SET IsDeleted = 1 WHERE ItemID = @ItemID", new Dictionary<string, object> { { "@ItemID", itemId } });
                dbManager.LogAudit(Session.CurrentUser?.UserID, "SoftDeleteItem", $"ItemID={itemId}");
                Toast.Show(this, "Item archived (soft-deleted). You can restore it from Archived Items.", Toast.ToastType.Success);
                await LoadInventoryDataAsync(); ClearInputFields();
            }
            catch (Exception ex) { MessageBox.Show($"Error archiving item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            finally { HideLoading(); }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            await StartCancelableOperation(async (progress, token) =>
            {
                this.InvokeIfRequired(() => ShowLoading("Saving item...", cancellable: true));
                try
                {
                    if (isAddMode)
                    {
                        string query = @"INSERT INTO dbo.ClothingInventory (ItemName, Category, Size, Color, Quantity, Price, Supplier) VALUES (@ItemName, @Category, @Size, @Color, @Quantity, @Price, @Supplier)";
                        await Task.Run(async () => await dbManager.ExecuteNonQueryAsync(query, GetParameters()), token);
                        dbManager.LogAudit(Session.CurrentUser?.UserID, "CreateItem", txtItemName.Text);
                        this.InvokeIfRequired(() => Toast.Show(this, "Item added successfully!", Toast.ToastType.Success));
                        await LoadInventoryDataAsync();
                    }
                    else if (isEditMode)
                    {
                        string query = @"UPDATE dbo.ClothingInventory SET ItemName=@ItemName, Category=@Category, Size=@Size, Color=@Color, Quantity=@Quantity, Price=@Price, Supplier=@Supplier WHERE ItemID=@ItemID";
                        var parameters = GetParameters(); parameters.Add("@ItemID", Convert.ToInt32(txtItemID.Text));
                        await Task.Run(async () => await dbManager.ExecuteNonQueryAsync(query, parameters), token);
                        dbManager.LogAudit(Session.CurrentUser?.UserID, "UpdateItem", txtItemName.Text);
                        this.InvokeIfRequired(() => Toast.Show(this, "Item updated successfully!", Toast.ToastType.Success));
                        await LoadInventoryDataAsync();
                    }

                    this.InvokeIfRequired(() => { SetFormMode("view"); ClearInputFields(); UpdateStatusLabel("Item saved successfully", StatusType.Success); });
                }
                finally { }
            }, "Saving item...");
        }

        private void btnCancel_Click(object sender, EventArgs e) { SetFormMode("view"); ClearInputFields(); }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                var dt = dgvInventory.DataSource as DataTable;
                if (dt == null || dt.Rows.Count == 0) { Toast.Show(this, "No data to export.", Toast.ToastType.Info); return; }
                using (var sfd = new SaveFileDialog { Filter = "CSV|*.csv" })
                {
                    if (sfd.ShowDialog() != DialogResult.OK) return;
                    using (var sw = new StreamWriter(sfd.FileName))
                    {
                        for (int i = 0; i < dt.Columns.Count; i++) { if (i > 0) sw.Write(","); sw.Write(EscapeCsv(dt.Columns[i].ColumnName)); }
                        sw.WriteLine();
                        foreach (DataRow r in dt.Rows)
                        {
                            for (int i = 0; i < dt.Columns.Count; i++) { if (i > 0) sw.Write(","); sw.Write(EscapeCsv(r[i]?.ToString() ?? string.Empty)); }
                            sw.WriteLine();
                        }
                    }
                    Toast.Show(this, "Exported.", Toast.ToastType.Success);
                }
            }
            catch (Exception ex) { MessageBox.Show($"Export failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private string EscapeCsv(string field)
        {
            if (field == null) return string.Empty;
            bool mustQuote = field.Contains(",") || field.Contains("\n") || field.Contains("\r") || field.Contains("\"");
            string escaped = field.Replace("\"", "\"\"");
            return mustQuote ? $"\"{escaped}\"" : escaped;
        }

        #endregion

        #region Form State Management

        private void SetFormMode(string mode)
        {
            switch (mode)
            {
                case "add": isAddMode = true; isEditMode = false; EnableInputFields(true); btnSave.Enabled = true; btnCancel.Enabled = true; btnAdd.Enabled = false; btnEdit.Enabled = false; btnDelete.Enabled = false; UpdateStatusLabel("Add mode - Enter new item details"); break;
                case "edit": isAddMode = false; isEditMode = true; EnableInputFields(true); btnSave.Enabled = true; btnCancel.Enabled = true; btnAdd.Enabled = false; btnEdit.Enabled = false; btnDelete.Enabled = false; UpdateStatusLabel("Edit mode - Modify item details"); break;
                default: isAddMode = false; isEditMode = false; EnableInputFields(false); btnSave.Enabled = false; btnCancel.Enabled = false; btnAdd.Enabled = true; btnEdit.Enabled = true; btnDelete.Enabled = true; UpdateStatusLabel("Ready"); break;
            }
        }

        private void EnableInputFields(bool enabled)
        {
            txtItemName.Enabled = enabled; cmbCategory.Enabled = enabled; cmbSize.Enabled = enabled; txtColor.Enabled = enabled; nudQuantity.Enabled = enabled; txtPrice.Enabled = enabled; txtSupplier.Enabled = enabled;
        }

        private void ClearInputFields()
        {
            txtItemID.Clear(); txtItemName.Clear(); cmbCategory.SelectedIndex = -1; cmbSize.SelectedIndex = -1; txtColor.Clear(); nudQuantity.Value = 0; txtPrice.Clear(); txtSupplier.Clear();
            inputErrorProvider.SetError(txtItemName, ""); inputErrorProvider.SetError(cmbCategory, ""); inputErrorProvider.SetError(cmbSize, ""); inputErrorProvider.SetError(txtColor, ""); inputErrorProvider.SetError(txtPrice, ""); inputErrorProvider.SetError(txtSupplier, "");
        }

        private void CmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var category = cmbCategory.SelectedItem?.ToString();
                cmbSize.Items.Clear();
                if (string.IsNullOrWhiteSpace(category)) return;

                if (category.IndexOf("shoe", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    cmbSize.Items.AddRange(predefinedShoeSizes);
                }
                else
                {
                    cmbSize.Items.AddRange(predefinedClothingSizes);
                }

                // include sizes from DB for this category
                Task.Run(async () =>
                {
                    try
                    {
                        var dt = await dbManager.ExecuteQueryAsync("SELECT DISTINCT Size FROM dbo.ClothingInventory WHERE Category = @Category ORDER BY Size", new Dictionary<string, object> { { "@Category", category } });
                        this.InvokeIfRequired(() =>
                        {
                            foreach (DataRow r in dt.Rows)
                            {
                                var v = r[0]?.ToString(); if (string.IsNullOrWhiteSpace(v)) continue; if (!cmbSize.Items.Contains(v)) cmbSize.Items.Add(v);
                            }
                        });
                    }
                    catch { }
                });

                cmbSize.SelectedIndex = -1;
            }
            catch { }
        }

        private void PopulateInputFields()
        {
            if (dgvInventory.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvInventory.SelectedRows[0];
                txtItemID.Text = row.Cells["ItemID"].Value?.ToString() ?? string.Empty;
                txtItemName.Text = row.Cells["ItemName"].Value?.ToString() ?? string.Empty;
                cmbCategory.SelectedItem = row.Cells["Category"].Value?.ToString();
                var sizeVal = row.Cells["Size"].Value?.ToString();
                if (!string.IsNullOrWhiteSpace(sizeVal)) { if (!cmbSize.Items.Contains(sizeVal)) cmbSize.Items.Add(sizeVal); cmbSize.SelectedItem = sizeVal; }
                txtColor.Text = row.Cells["Color"].Value?.ToString() ?? string.Empty;
                nudQuantity.Value = Convert.ToDecimal(row.Cells["Quantity"].Value ?? 0);
                txtPrice.Text = row.Cells["Price"].Value?.ToString() ?? string.Empty;
                txtSupplier.Text = row.Cells["Supplier"].Value?.ToString() ?? string.Empty;
            }
        }

        #endregion

        #region Validation and Helpers

        private bool ValidateInputs()
        {
            inputErrorProvider.SetError(txtItemName, string.Empty); inputErrorProvider.SetError(cmbCategory, string.Empty); inputErrorProvider.SetError(cmbSize, string.Empty); inputErrorProvider.SetError(txtColor, string.Empty); inputErrorProvider.SetError(txtPrice, string.Empty); inputErrorProvider.SetError(txtSupplier, string.Empty);
            Control firstInvalid = null;
            if (string.IsNullOrWhiteSpace(txtItemName.Text)) { inputErrorProvider.SetError(txtItemName, "Please enter an item name."); firstInvalid = firstInvalid ?? txtItemName; }
            if (cmbCategory.SelectedIndex == -1) { inputErrorProvider.SetError(cmbCategory, "Please select a category."); firstInvalid = firstInvalid ?? cmbCategory; }
            if (cmbSize.SelectedIndex == -1) { inputErrorProvider.SetError(cmbSize, "Please select a size."); firstInvalid = firstInvalid ?? cmbSize; }
            if (string.IsNullOrWhiteSpace(txtColor.Text)) { inputErrorProvider.SetError(txtColor, "Please enter a color."); firstInvalid = firstInvalid ?? txtColor; }
            if (string.IsNullOrWhiteSpace(txtPrice.Text) || !decimal.TryParse(txtPrice.Text, NumberStyles.AllowDecimalPoint, filipinoCulture, out _)) { inputErrorProvider.SetError(txtPrice, "Please enter a valid price."); firstInvalid = firstInvalid ?? txtPrice; }
            if (string.IsNullOrWhiteSpace(txtSupplier.Text)) { inputErrorProvider.SetError(txtSupplier, "Please enter a supplier."); firstInvalid = firstInvalid ?? txtSupplier; }

            if (firstInvalid == null && cmbCategory.SelectedItem?.ToString() == "Others" && string.IsNullOrWhiteSpace(cmbSize.Text)) { }
            else if (firstInvalid != null) this.BeginInvoke(new Action(() => { try { firstInvalid.Focus(); } catch { } }));
            return firstInvalid == null;
        }

        #endregion

        private enum StatusType { Info, Success, Warning, Error, Loading }

        private void UpdateStatusLabel(string message, StatusType type = StatusType.Info)
        {
            try
            {
                if (toolStripStatusLabel == null) return;
                toolStripStatusLabel.Text = $"{message} - {DateTime.Now:HH:mm:ss}";
                switch (type)
                {
                    case StatusType.Success: toolStripStatusLabel.ForeColor = Color.FromArgb(39, 174, 96); break;
                    case StatusType.Error: toolStripStatusLabel.ForeColor = Color.FromArgb(231, 76, 60); break;
                    case StatusType.Warning: toolStripStatusLabel.ForeColor = Color.FromArgb(243, 156, 18); break;
                    case StatusType.Loading: toolStripStatusLabel.ForeColor = Color.FromArgb(155, 89, 182); break;
                    default: toolStripStatusLabel.ForeColor = Color.FromArgb(52, 152, 219); break;
                }
            }
            catch { }
        }

        private void ApplyRolePermissions()
        {
            try
            {
                var user = Session.CurrentUser;
                if (user == null) { try { btnAdd.Enabled = false; btnEdit.Enabled = false; btnDelete.Enabled = false; } catch { } try { if (generateTestDataToolStripMenuItem != null) generateTestDataToolStripMenuItem.Visible = false; } catch { } return; }
                string role = user.Role?.ToLowerInvariant() ?? "cashier";
                switch (role)
                {
                    case "admin": btnAdd.Enabled = true; btnEdit.Enabled = true; btnDelete.Enabled = true; try { if (generateTestDataToolStripMenuItem != null) generateTestDataToolStripMenuItem.Visible = true; } catch { } break;
                    case "manager": btnAdd.Enabled = true; btnEdit.Enabled = true; btnDelete.Enabled = true; try { if (generateTestDataToolStripMenuItem != null) generateTestDataToolStripMenuItem.Visible = false; } catch { } break;
                    default: btnAdd.Enabled = false; btnEdit.Enabled = false; btnDelete.Enabled = false; try { if (generateTestDataToolStripMenuItem != null) generateTestDataToolStripMenuItem.Visible = false; } catch { } break;
                }
                UpdateStatusLabel($"Logged in as {user.Username} ({user.Role})", StatusType.Info);
            }
            catch { }
        }

        private void RebuildMainMenu()
        {
            try
            {
                var mainMenu = this.MainMenuStrip ?? this.Controls.OfType<MenuStrip>().FirstOrDefault();
                if (mainMenu == null) { mainMenu = new MenuStrip { Name = "mainMenu", Dock = DockStyle.Top }; this.Controls.Add(mainMenu); this.MainMenuStrip = mainMenu; }
            }
            catch { }
        }

        private Dictionary<string, object> GetParameters()
        {
            try
            {
                return new Dictionary<string, object>
                {
                    { "@ItemName", txtItemName.Text.Trim() },
                    { "@Category", cmbCategory.SelectedItem?.ToString() ?? string.Empty },
                    { "@Size", cmbSize.SelectedItem?.ToString() ?? string.Empty },
                    { "@Color", txtColor.Text.Trim() },
                    { "@Quantity", (int)nudQuantity.Value },
                    { "@Price", decimal.TryParse(txtPrice.Text, NumberStyles.AllowDecimalPoint, filipinoCulture, out var p) ? p : 0m },
                    { "@Supplier", txtSupplier.Text.Trim() }
                };
            }
            catch { return new Dictionary<string, object>(); }
        }

        private async void GenerateTestData(int count)
        {
            try
            {
                await StartCancelableOperation(async (progress, token) =>
                {
                    var rand = new Random();
                    string[] categories = { "T-Shirts", "Jeans", "Jackets", "Dresses", "Shoes", "Accessories", "Shorts", "Polo Shirts" };
                    string[] clothingSizes = predefinedClothingSizes;
                    string[] colors = { "Black", "White", "Blue", "Red", "Green", "Gray" };
                    string[] suppliers = { "SM Department Store", "Bench", "Penshoppe", "Uniqlo Manila", "H&M Philippines" };

                    for (int i = 0; i < count; i++)
                    {
                        token.ThrowIfCancellationRequested();
                        string category = categories[rand.Next(categories.Length)];
                        string size = category.IndexOf("shoe", StringComparison.OrdinalIgnoreCase) >= 0 ? predefinedShoeSizes[rand.Next(predefinedShoeSizes.Length)] : clothingSizes[rand.Next(clothingSizes.Length)];
                        string name = $"Sample {category.TrimEnd('s')} {rand.Next(1000, 9999)}";
                        decimal price = Math.Round((decimal)(rand.NextDouble() * 4900 + 100), 2);

                        string query = @"INSERT INTO dbo.ClothingInventory (ItemName, Category, Size, Color, Quantity, Price, Supplier) VALUES (@ItemName, @Category, @Size, @Color, @Quantity, @Price, @Supplier)";
                        var parameters = new Dictionary<string, object>
                        {
                            { "@ItemName", name }, { "@Category", category }, { "@Size", size }, { "@Color", colors[rand.Next(colors.Length)] }, { "@Quantity", rand.Next(1, 100) }, { "@Price", price }, { "@Supplier", suppliers[rand.Next(suppliers.Length)] }
                        };

                        await dbManager.ExecuteNonQueryAsync(query, parameters);
                        int percent = (int)((i + 1) / (double)count * 100);
                        progress.Report(percent);
                    }

                    this.InvokeIfRequired(() => Toast.Show(this, $"{count} test items generated successfully!", Toast.ToastType.Success));
                    await LoadInventoryDataAsync();
                }, "Generating test data...");
            }
            catch (OperationCanceledException) { Toast.Show(this, "Test data generation cancelled.", Toast.ToastType.Info); }
            catch (Exception ex) { MessageBox.Show($"Error generating test data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        // Menu item handlers added to match designer wiring
        private void archivedItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenArchivedItems", "Archived items opened");
                var form = new ArchivedItemsForm(dbManager);
                form.ShowDialog(this);
                _ = LoadInventoryDataAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening archived items: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ImportExportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Import/Export feature coming soon!", "Feature Not Available", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenSettings", "Settings opened");
                var form = new SettingsForm();
                form.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Kids Merch Inventory Management System\n\n" +
                "Version 1.0\n\n" +
                "A simple and efficient inventory management solution.\n\n" +
                "� 2024 Kids Merch",
                "About Kids Merch",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        #region Designer event handlers (stubs)

        private async void newSaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try { dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenSales", "Sales form opened"); using var salesForm = new SalesForm(dbManager); salesForm.ShowDialog(this); await LoadInventoryDataAsync(); } catch { }
        }

        private void transactionHistoryToolStripMenuItem_Click(object sender, EventArgs e) { try { dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenTransactionHistory", "Transaction history opened"); var historyForm = new TransactionHistoryForm(dbManager); historyForm.ShowDialog(this); } catch { } }
        private void reportsToolStripMenuItem_Click(object sender, EventArgs e) { try { dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenReports", "Reports opened"); var reportsForm = new ReportsForm(dbManager); reportsForm.ShowDialog(this); } catch { } }
        private void generate10ItemsToolStripMenuItem_Click(object sender, EventArgs e) => GenerateTestData(10);
        private void generate50ItemsToolStripMenuItem_Click(object sender, EventArgs e) => GenerateTestData(50);
        private void generate100ItemsToolStripMenuItem_Click(object sender, EventArgs e) => GenerateTestData(100);

        private async void clearAllDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = ConfirmDialog.Show(this, "Are you sure you want to ARCHIVE ALL inventory data? This will mark items as archived and can be restored from Archived Items. To permanently delete, use the Archived Items screen.", "Confirm Archive All", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ShowLoading("Archiving all inventory...");
                try { await dbManager.ExecuteNonQueryAsync("UPDATE dbo.ClothingInventory SET IsDeleted = 1 WHERE IsDeleted = 0"); dbManager.LogAudit(Session.CurrentUser?.UserID, "ArchiveAllData", "All inventory archived"); Toast.Show(this, "All inventory has been archived. Use Archived Items to restore or permanently delete.", Toast.ToastType.Success); await LoadInventoryDataAsync(); ClearInputFields(); }
                catch (Exception ex) { MessageBox.Show($"Failed to archive data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); UpdateStatusLabel($"Error archiving data: {ex.Message}", StatusType.Error); }
                finally { HideLoading(); }
            }
        }

        private void userManagementToolStripMenuItem_Click(object sender, EventArgs e) { try { dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenUserManagement", "User management opened"); var form = new UserManagementForm(dbManager); form.ShowDialog(this); } catch { } }
        private void auditTrailToolStripMenuItem_Click(object sender, EventArgs e) { try { dbManager.LogAudit(Session.CurrentUser?.UserID, "OpenAuditTrail", "Audit trail opened"); var form = new AuditTrailForm(dbManager); form.ShowDialog(this); } catch { } }

        private void dgvInventory_SelectionChanged(object sender, EventArgs e) { try { if (dgvInventory.SelectedRows.Count > 0 && !isAddMode && !isEditMode) PopulateInputFields(); } catch { } }

        #endregion
    }

    static class ControlExtensions
    {
        public static void InvokeIfRequired(this Control c, Action action) { if (c == null) return; if (c.IsDisposed) return; if (c.InvokeRequired) c.Invoke(action); else action(); }
    }

}
