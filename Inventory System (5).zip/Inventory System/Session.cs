namespace KidsMerch
{
    public static class Session
    {
        // Current user may be null when nobody is logged in
        public static User? CurrentUser { get; set; }
    }
}
