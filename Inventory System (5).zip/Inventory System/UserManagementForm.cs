using System;
using System.Data;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class UserManagementForm : Form
    {
        private DatabaseManager dbManager;

        public UserManagementForm(DatabaseManager dbManager)
        {
            InitializeComponent();
            this.dbManager = dbManager;
        }

        private void UserManagementForm_Load(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void LoadUsers()
        {
            var dt = dbManager.GetUsers();
            dgvUsers.DataSource = dt;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            using (var dlg = new CreateUserDialog())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    // create user
                    dbManager.CreateUser(dlg.Username, dlg.Password, dlg.Role, dlg.FullName);
                    dbManager.LogAudit(Session.CurrentUser?.UserID, "CreateUser", dlg.Username);
                    LoadUsers();
                }
            }
        }

        private void btnResetPassword_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a user first.");
                return;
            }

            int userId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserID"].Value);
            using (var dlg = new ResetPasswordDialog())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    dbManager.ResetPassword(userId, dlg.NewPassword);
                    dbManager.LogAudit(Session.CurrentUser?.UserID, "ResetPassword", $"UserID={userId}");
                    MessageBox.Show("Password reset.");
                }
            }
        }
    }
}
