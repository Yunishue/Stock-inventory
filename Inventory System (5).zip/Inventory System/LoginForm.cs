using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class LoginForm : Form
    {
        private DatabaseManager dbManager;
        private bool isSetupMode = false;

        public LoginForm(DatabaseManager dbManager)
        {
            InitializeComponent();
            this.dbManager = dbManager;

            try
            {
                var dt = dbManager.ExecuteQuery("SELECT COUNT(*) as C FROM dbo.Users");
                int count = 0;
                if (dt.Rows.Count > 0)
                    count = Convert.ToInt32(dt.Rows[0]["C"]);

                if (count == 0)
                {
                    isSetupMode = true;
                    this.Text = "Create Admin Account";
                    btnLogin.Text = "Create Admin";
                    MessageBox.Show("No users found. Please create an admin account.", "Setup", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                // ignore - if users table missing, DatabaseManager.InitializeDatabase should have created it
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter username and password.", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (isSetupMode)
            {
                // Create admin with raw password (DatabaseManager handles hashing + salt)
                try
                {
                    dbManager.CreateUser(username, password, "admin", username);
                    var row = dbManager.AuthenticateUser(username, password);
                    if (row != null)
                    {
                        var user = new User
                        {
                            UserID = Convert.ToInt32(row["UserID"]),
                            Username = row["Username"].ToString(),
                            Role = row["Role"].ToString(),
                            FullName = row["FullName"].ToString()
                        };
                        Session.CurrentUser = user;
                        dbManager.LogAudit(user.UserID, "CreateAdmin", "Admin account created");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Failed to authenticate newly created user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error creating admin: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                return;
            }

            var rowAuth = dbManager.AuthenticateUser(username, password);
            if (rowAuth != null)
            {
                var user = new User
                {
                    UserID = Convert.ToInt32(rowAuth["UserID"]),
                    Username = rowAuth["Username"].ToString(),
                    Role = rowAuth["Role"].ToString(),
                    FullName = rowAuth["FullName"].ToString()
                };
                Session.CurrentUser = user;
                dbManager.LogAudit(user.UserID, "Login", "User logged in");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid credentials.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
