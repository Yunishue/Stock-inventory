using System;
using System.Text.Json;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace KidsMerch
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Initialize logger
            Logger.Initialize();
            Logger.Info("Application starting");

            // Global exception handlers
            Application.ThreadException += (s, e) =>
            {
                Logger.Error("Unhandled UI thread exception", e.Exception);
                MessageBox.Show($"An unexpected error occurred: {e.Exception.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                var ex = e.ExceptionObject as Exception;
                Logger.Error("Unhandled domain exception", ex ?? new Exception("Unknown"));
            };

            string connString = null;
            string configPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json");

            try
            {
                if (System.IO.File.Exists(configPath))
                {
                    var json = System.IO.File.ReadAllText(configPath);
                    using var doc = JsonDocument.Parse(json);

                    if (doc.RootElement.TryGetProperty("ConnectionStrings", out var csElem) && csElem.ValueKind == JsonValueKind.Object)
                    {
                        if (csElem.TryGetProperty("DefaultConnection", out var defConn))
                        {
                            connString = defConn.GetString();
                        }
                        else if (csElem.TryGetProperty("Default", out var def))
                        {
                            connString = def.GetString();
                        }
                        else
                        {
                            foreach (var p in csElem.EnumerateObject())
                            {
                                if (p.Value.ValueKind == JsonValueKind.String)
                                {
                                    connString = p.Value.GetString();
                                    break;
                                }
                            }
                        }
                    }

                    if (string.IsNullOrWhiteSpace(connString) && doc.RootElement.TryGetProperty("Database", out var dbElem) && dbElem.ValueKind == JsonValueKind.Object)
                    {
                        string server = dbElem.TryGetProperty("Server", out var s) ? s.GetString() : null;
                        string name = dbElem.TryGetProperty("Name", out var n) ? n.GetString() : null;
                        string user = dbElem.TryGetProperty("User", out var u) ? u.GetString() : null;
                        string password = dbElem.TryGetProperty("Password", out var p) ? p.GetString() : null;

                        if (!string.IsNullOrWhiteSpace(server))
                        {
                            var builder = new SqlConnectionStringBuilder
                            {
                                DataSource = server
                            };

                            if (!string.IsNullOrWhiteSpace(name))
                                builder.InitialCatalog = name;

                            if (!string.IsNullOrWhiteSpace(user))
                            {
                                builder.UserID = user;
                                builder.Password = password ?? string.Empty;
                                builder.IntegratedSecurity = false;
                            }
                            else
                            {
                                builder.IntegratedSecurity = true;
                            }

                            builder.Encrypt = false;
                            builder.TrustServerCertificate = true;
                            builder.ConnectTimeout = 10;

                            connString = builder.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Failed to read appsettings.json", ex);
                connString = null;
            }

            if (string.IsNullOrWhiteSpace(connString))
            {
                // fallback to LocalDB default
                var builder = new SqlConnectionStringBuilder();
                builder.DataSource = @"(localdb)\MSSQLLocalDB";
                builder.InitialCatalog = "KidsMerchDB";
                builder.IntegratedSecurity = true;
                connString = builder.ToString();
                Logger.Info("Using fallback LocalDB connection string");
            }

            // Log masked connection string for diagnostics
            try
            {
                var maskBuilder = new SqlConnectionStringBuilder(connString);
                if (!string.IsNullOrEmpty(maskBuilder.Password)) maskBuilder.Password = "********";
                Logger.Info($"DB Connection: DataSource={maskBuilder.DataSource}; InitialCatalog={maskBuilder.InitialCatalog}; UserID={(maskBuilder.IntegratedSecurity ? "(Integrated)" : maskBuilder.UserID)}");

                if (maskBuilder.DataSource.IndexOf("(localdb)", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    Logger.Error("Connection targets LocalDB. If LocalDB is not installed, set DB_CONNECTION env var or update appsettings.json with your server.");
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Failed to mask/log connection string", ex);
            }

            Logger.Info("Connection string prepared");

            var dbManager = new DatabaseManager(connString);
            dbManager.InitializeDatabase();

            // First-time setup: if no users exist, prompt to create an admin
            try
            {
                var users = dbManager.GetUsers();
                if (users == null || users.Rows.Count == 0)
                {
                    MessageBox.Show("No users found. Please create an initial admin account.", "First-time Setup", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    using (var createDlg = new CreateUserDialog())
                    {
                        createDlg.ShowInTaskbar = false;
                        if (createDlg.ShowDialog() == DialogResult.OK)
                        {
                            dbManager.CreateUser(createDlg.Username, createDlg.Password, createDlg.Role, createDlg.FullName);
                            MessageBox.Show("Admin user created. You can now log in.", "Setup Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Setup cancelled. The application will exit.", "Setup", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Failed during first-time user setup", ex);
            }

            // Show login form first
            using (var loginForm = new LoginForm(dbManager))
            {
                var result = loginForm.ShowDialog();
                if (result == DialogResult.OK && Session.CurrentUser != null)
                {
                    Application.Run(new Form1(dbManager));
                }
            }

            Logger.Info("Application exiting");
        }
    }
}