using System;
using System.Data;
using System.Windows.Forms;
using System.Collections.Generic;

namespace KidsMerch
{
    public class ArchivedItemsForm : Form
    {
        private readonly DatabaseManager dbManager;
        private DataGridView dgvArchived;
        private Button btnRestore;
        private Button btnPermanentDelete;
        private Button btnRefresh;

        public ArchivedItemsForm(DatabaseManager dbManager)
        {
            this.dbManager = dbManager ?? throw new ArgumentNullException(nameof(dbManager));
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Archived Items";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 900;
            this.Height = 500;

            dgvArchived = new DataGridView { Dock = DockStyle.Top, Height = 380, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };

            btnRestore = new Button { Text = "Restore", Left = 10, Width = 120, Top = 390 };
            btnPermanentDelete = new Button { Text = "Delete Permanently", Left = 140, Width = 160, Top = 390 };
            btnRefresh = new Button { Text = "Refresh", Left = 310, Width = 100, Top = 390 };

            btnRestore.Click += btnRestore_Click;
            btnPermanentDelete.Click += btnPermanentDelete_Click;
            btnRefresh.Click += btnRefresh_Click;

            this.Controls.Add(dgvArchived);
            this.Controls.Add(btnRestore);
            this.Controls.Add(btnPermanentDelete);
            this.Controls.Add(btnRefresh);

            this.Load += ArchivedItemsForm_Load;
        }

        private void ArchivedItemsForm_Load(object sender, EventArgs e)
        {
            LoadArchivedItems();
        }

        private void LoadArchivedItems()
        {
            try
            {
                string query = "SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price, Supplier, DateAdded FROM dbo.ClothingInventory WHERE IsDeleted = 1 ORDER BY DateAdded DESC";
                var dt = dbManager.ExecuteQuery(query);
                dgvArchived.DataSource = dt;

                if (dgvArchived.Columns.Contains("Price"))
                {
                    dgvArchived.Columns["Price"].DefaultCellStyle.Format = "N2";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load archived items: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            if (dgvArchived.SelectedRows.Count == 0)
            {
                Toast.Show(this, "Please select an item to restore.", Toast.ToastType.Warning);
                return;
            }

            int itemId = Convert.ToInt32(dgvArchived.SelectedRows[0].Cells["ItemID"].Value);
            try
            {
                string query = "UPDATE dbo.ClothingInventory SET IsDeleted = 0 WHERE ItemID = @ItemID";
                var parameters = new Dictionary<string, object> { { "@ItemID", itemId } };
                dbManager.ExecuteNonQuery(query, parameters);
                dbManager.LogAudit(Session.CurrentUser?.UserID, "RestoreItem", $"ItemID={itemId}");
                Toast.Show(this, "Item restored.", Toast.ToastType.Success);
                LoadArchivedItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to restore item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPermanentDelete_Click(object sender, EventArgs e)
        {
            if (dgvArchived.SelectedRows.Count == 0)
            {
                Toast.Show(this, "Please select an item to permanently delete.", Toast.ToastType.Warning);
                return;
            }

            int itemId = Convert.ToInt32(dgvArchived.SelectedRows[0].Cells["ItemID"].Value);
            var result = ConfirmDialog.Show(this, "Permanently delete this item? This cannot be undone.", "Confirm", MessageBoxButtons.YesNo);
            if (result != DialogResult.Yes) return;

            try
            {
                string query = "DELETE FROM dbo.ClothingInventory WHERE ItemID = @ItemID";
                var parameters = new Dictionary<string, object> { { "@ItemID", itemId } };
                dbManager.ExecuteNonQuery(query, parameters);
                dbManager.LogAudit(Session.CurrentUser?.UserID, "PermanentDeleteItem", $"ItemID={itemId}");
                Toast.Show(this, "Item permanently deleted.", Toast.ToastType.Success);
                LoadArchivedItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to delete item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadArchivedItems();
        }
    }
}
