using System.Text;

namespace KidsMerch
{
    /// <summary>
    /// Helper class for CSV operations with proper escaping
    /// </summary>
    public static class CsvHelper
    {
        /// <summary>
        /// Escapes a CSV field - wraps in quotes if it contains comma, quote, or newline
        /// </summary>
        public static string EscapeCsvField(string field)
        {
            if (string.IsNullOrEmpty(field))
                return "";

            // If field contains comma, quote, or newline, wrap it in quotes
            if (field.Contains(",") || field.Contains("\"") || field.Contains("\n") || field.Contains("\r"))
            {
                // Escape existing quotes by doubling them
                field = field.Replace("\"", "\"\"");
                return $"\"{field}\"";
            }

            return field;
        }

        /// <summary>
        /// Converts a DataGridView to a properly formatted CSV string
        /// </summary>
        public static string DataGridViewToCsv(DataGridView dgv)
        {
            StringBuilder sb = new StringBuilder();

            // Write column headers
            for (int i = 0; i < dgv.Columns.Count; i++)
            {
                sb.Append(EscapeCsvField(dgv.Columns[i].HeaderText));
                if (i < dgv.Columns.Count - 1)
                    sb.Append(",");
            }
            sb.AppendLine();

            // Write data rows
            foreach (DataGridViewRow row in dgv.Rows)
            {
                if (!row.IsNewRow)
                {
                    for (int i = 0; i < dgv.Columns.Count; i++)
                    {
                        string cellValue = row.Cells[i].Value?.ToString() ?? "";
                        sb.Append(EscapeCsvField(cellValue));
                        if (i < dgv.Columns.Count - 1)
                            sb.Append(",");
                    }
                    sb.AppendLine();
                }
            }

            return sb.ToString();
        }
    }
}
