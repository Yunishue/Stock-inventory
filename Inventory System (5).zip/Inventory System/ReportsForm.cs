﻿using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace KidsMerch
{
    public partial class ReportsForm : Form
    {
        private DatabaseManager dbManager;
        private static readonly CultureInfo filipinoCulture = new CultureInfo("fil-PH");

        public ReportsForm(DatabaseManager dbManager)
        {
            InitializeComponent();
            this.dbManager = dbManager;
        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {
            ThemeManager.ApplyTheme(this);

            // Set default date range
            dtpStartDate.Value = DateTime.Now.AddDays(-30);
            dtpEndDate.Value = DateTime.Now;

            // Set default report type
            cmbReportType.SelectedIndex = 0;

            LoadSelectedReport();
        }

        private void cmbReportType_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadSelectedReport();
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            LoadSelectedReport();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadSelectedReport();
        }

        private void LoadSelectedReport()
        {
            string reportType = cmbReportType.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(reportType))
                return;

            try
            {
                DateTime startDate = dtpStartDate.Value.Date;
                DateTime endDate = dtpEndDate.Value.Date.AddDays(1).AddSeconds(-1);

                switch (reportType)
                {
                    case "Best Selling Items":
                        LoadBestSellingItems(startDate, endDate);
                        break;
                    case "Sales by Category":
                        LoadSalesByCategory(startDate, endDate);
                        break;
                    case "Daily Sales Summary":
                        LoadDailySalesSummary(startDate, endDate);
                        break;
                    case "Low Stock Alert":
                        LoadLowStockAlert();
                        break;
                    case "Inventory Value":
                        LoadInventoryValue();
                        break;
                }

                lblReportTitle.Text = $"📊 {reportType}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating report: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadBestSellingItems(DateTime startDate, DateTime endDate)
        {
            DataTable dt = dbManager.GetBestSellingItems(startDate, endDate, 20);
            dgvReport.DataSource = dt;

            FormatCurrencyColumns("TotalRevenue", "AveragePrice");

            if (dgvReport.Columns.Contains("TotalSold"))
            {
                dgvReport.Columns["TotalSold"].HeaderText = "Units Sold";
            }

            lblSummary.Text = $"Top 20 best selling items from {startDate:MM/dd/yyyy} to {endDate:MM/dd/yyyy}";
        }

        private void LoadSalesByCategory(DateTime startDate, DateTime endDate)
        {
            DataTable dt = dbManager.GetSalesByCategory(startDate, endDate);
            dgvReport.DataSource = dt;

            FormatCurrencyColumns("TotalRevenue");

            if (dgvReport.Columns.Contains("ItemsSold"))
            {
                dgvReport.Columns["ItemsSold"].HeaderText = "Items Sold";
            }
            if (dgvReport.Columns.Contains("TransactionCount"))
            {
                dgvReport.Columns["TransactionCount"].HeaderText = "Transactions";
            }

            decimal totalRevenue = 0;
            foreach (DataRow row in dt.Rows)
            {
                totalRevenue += Convert.ToDecimal(row["TotalRevenue"]);
            }

            lblSummary.Text = $"Total Revenue: ₱{totalRevenue:N2} from {startDate:MM/dd/yyyy} to {endDate:MM/dd/yyyy}";
        }

        private void LoadDailySalesSummary(DateTime startDate, DateTime endDate)
        {
            DataTable dt = dbManager.GetSalesSummary(startDate, endDate);
            dgvReport.DataSource = dt;

            FormatCurrencyColumns("TotalSales", "AverageSale");

            if (dgvReport.Columns.Contains("SalesDate"))
            {
                dgvReport.Columns["SalesDate"].HeaderText = "Date";
                dgvReport.Columns["SalesDate"].DefaultCellStyle.Format = "MM/dd/yyyy";
            }
            if (dgvReport.Columns.Contains("TransactionCount"))
            {
                dgvReport.Columns["TransactionCount"].HeaderText = "Transactions";
            }

            decimal totalSales = 0;
            int totalTransactions = 0;
            foreach (DataRow row in dt.Rows)
            {
                totalSales += Convert.ToDecimal(row["TotalSales"]);
                totalTransactions += Convert.ToInt32(row["TransactionCount"]);
            }

            lblSummary.Text = $"Total: ₱{totalSales:N2} from {totalTransactions} transactions";
        }

        private void LoadLowStockAlert()
        {
            string query = @"SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price, Supplier
                           FROM ClothingInventory 
                           WHERE Quantity < 10 
                           ORDER BY Quantity ASC";

            DataTable dt = dbManager.ExecuteQuery(query);
            dgvReport.DataSource = dt;

            FormatCurrencyColumns("Price");

            if (dgvReport.Columns.Contains("Quantity"))
            {
                dgvReport.Columns["Quantity"].DefaultCellStyle.BackColor = Color.FromArgb(254, 226, 226);
                dgvReport.Columns["Quantity"].DefaultCellStyle.ForeColor = Color.FromArgb(153, 27, 27);
            }

            lblSummary.Text = $"⚠️ {dt.Rows.Count} items are low in stock (less than 10 units)";
        }

        private void LoadInventoryValue()
        {
            string query = @"SELECT 
                               ItemID,
                               ItemName, 
                               Category, 
                               Size, 
                               Color, 
                               Quantity, 
                               Price,
                               (Quantity * Price) as TotalValue
                           FROM ClothingInventory 
                           ORDER BY TotalValue DESC";

            DataTable dt = dbManager.ExecuteQuery(query);
            dgvReport.DataSource = dt;

            FormatCurrencyColumns("Price", "TotalValue");

            decimal totalInventoryValue = 0;
            int totalItems = 0;
            foreach (DataRow row in dt.Rows)
            {
                totalInventoryValue += Convert.ToDecimal(row["TotalValue"]);
                totalItems += Convert.ToInt32(row["Quantity"]);
            }

            lblSummary.Text = $"Total Inventory Value: ₱{totalInventoryValue:N2} ({totalItems} items in stock)";
        }

        private void FormatCurrencyColumns(params string[] columnNames)
        {
            foreach (string columnName in columnNames)
            {
                if (dgvReport.Columns.Contains(columnName))
                {
                    dgvReport.Columns[columnName].DefaultCellStyle.Format = "C2";
                    dgvReport.Columns[columnName].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvReport.Columns[columnName].HeaderText = columnName.Replace("Total", "Total ").Replace("Average", "Avg ") + " (PHP)";
                }
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvReport.Rows.Count == 0)
                {
                    MessageBox.Show("No data to export.", "Export",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string reportType = cmbReportType.SelectedItem?.ToString().Replace(" ", "_");

                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
                    Title = "Export Report",
                    FileName = $"{reportType}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string csvContent = CsvHelper.DataGridViewToCsv(dgvReport);
                    System.IO.File.WriteAllText(saveFileDialog.FileName, csvContent);

                    MessageBox.Show("Report exported successfully!", "Export Complete",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error exporting report: {ex.Message}", "Export Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}