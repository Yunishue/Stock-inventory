﻿using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;

namespace KidsMerch
{
    public partial class SalesForm : Form
    {
        private DatabaseManager dbManager;
        private SalesTransaction currentTransaction;
        private static readonly CultureInfo filipinoCulture = new CultureInfo("fil-PH");

        public SalesForm(DatabaseManager dbManager)
        {
            InitializeComponent();
            this.dbManager = dbManager;
            currentTransaction = new SalesTransaction();
        }

        private void SalesForm_Load(object sender, EventArgs e)
        {
            LoadAvailableItems();
            ResetTransaction();
            ThemeManager.ApplyTheme(this);
            cmbPaymentMethod.SelectedIndex = 0;
            dtpTransactionDate.Value = DateTime.Now;
            UpdateTotals();
        }

        private void LoadAvailableItems()
        {
            try
            {
                string query = "SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price FROM ClothingInventory WHERE Quantity > 0 AND IsDeleted = 0 ORDER BY ItemName";
                DataTable dt = dbManager.ExecuteQuery(query);
                dgvAvailableItems.DataSource = dt;

                if (dgvAvailableItems.Columns.Contains("Price"))
                {
                    dgvAvailableItems.Columns["Price"].DefaultCellStyle.Format = "C2";
                    dgvAvailableItems.Columns["Price"].DefaultCellStyle.FormatProvider = filipinoCulture;
                    dgvAvailableItems.Columns["Price"].HeaderText = "Price (PHP)";
                }
                lblAvailableCount.Text = $"{dt.Rows.Count} items available";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading items: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (dgvAvailableItems.SelectedRows.Count == 0)
            {
                Toast.Show(this, "Please select an item to add.", Toast.ToastType.Warning);
                return;
            }

            try
            {
                DataGridViewRow row = dgvAvailableItems.SelectedRows[0];
                int itemId = Convert.ToInt32(row.Cells["ItemID"].Value);
                string itemName = row.Cells["ItemName"].Value.ToString();
                string category = row.Cells["Category"].Value.ToString();
                string size = row.Cells["Size"].Value.ToString();
                string color = row.Cells["Color"].Value.ToString();
                int availableQty = Convert.ToInt32(row.Cells["Quantity"].Value);
                decimal price = Convert.ToDecimal(row.Cells["Price"].Value);
                int requestedQty = (int)nudQuantity.Value;

                if (requestedQty <= 0)
                {
                    Toast.Show(this, "Please enter a valid quantity.", Toast.ToastType.Warning);
                    return;
                }

                var existingItem = currentTransaction.Items.FirstOrDefault(i => i.ItemID == itemId);
                int totalQtyInCart = existingItem?.Quantity ?? 0;

                if (totalQtyInCart + requestedQty > availableQty)
                {
                    Toast.Show(this, $"Not enough stock! Available: {availableQty}, Already in cart: {totalQtyInCart}", Toast.ToastType.Warning);
                    return;
                }

                if (existingItem != null)
                {
                    existingItem.Quantity += requestedQty;
                    existingItem.CalculateSubtotal();
                }
                else
                {
                    var item = new SalesTransactionItem
                    {
                        ItemID = itemId,
                        ItemName = itemName,
                        Category = category,
                        Size = size,
                        Color = color,
                        Quantity = requestedQty,
                        UnitPrice = price
                    };
                    item.CalculateSubtotal();
                    currentTransaction.Items.Add(item);
                }

                RefreshCart();
                UpdateTotals();
                nudQuantity.Value = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemoveFromCart_Click(object sender, EventArgs e)
        {
            if (dgvCart.SelectedRows.Count == 0)
            {
                Toast.Show(this, "Please select an item to remove.", Toast.ToastType.Warning);
                return;
            }

            try
            {
                int index = dgvCart.SelectedRows[0].Index;
                currentTransaction.Items.RemoveAt(index);
                RefreshCart();
                UpdateTotals();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error removing item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClearCart_Click(object sender, EventArgs e)
        {
            if (currentTransaction.Items.Count == 0)
                return;

            DialogResult result = ConfirmDialog.Show(this, "Clear all items from cart?", "Confirm Clear", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                currentTransaction.Items.Clear();
                RefreshCart();
                UpdateTotals();
            }
        }

        private void RefreshCart()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ItemName", typeof(string));
            dt.Columns.Add("Category", typeof(string));
            dt.Columns.Add("Size", typeof(string));
            dt.Columns.Add("Color", typeof(string));
            dt.Columns.Add("Quantity", typeof(int));
            dt.Columns.Add("UnitPrice", typeof(decimal));
            dt.Columns.Add("Subtotal", typeof(decimal));

            foreach (var item in currentTransaction.Items)
            {
                dt.Rows.Add(item.ItemName, item.Category, item.Size, item.Color,
                    item.Quantity, item.UnitPrice, item.Subtotal);
            }

            dgvCart.DataSource = dt;

            if (dgvCart.Columns.Contains("UnitPrice"))
            {
                dgvCart.Columns["UnitPrice"].DefaultCellStyle.Format = "C2";
                dgvCart.Columns["UnitPrice"].DefaultCellStyle.FormatProvider = filipinoCulture;
                dgvCart.Columns["UnitPrice"].HeaderText = "Price (PHP)";
            }

            if (dgvCart.Columns.Contains("Subtotal"))
            {
                dgvCart.Columns["Subtotal"].DefaultCellStyle.Format = "C2";
                dgvCart.Columns["Subtotal"].DefaultCellStyle.FormatProvider = filipinoCulture;
                dgvCart.Columns["Subtotal"].HeaderText = "Subtotal (PHP)";
            }
        }

        private void UpdateTotals()
        {
            currentTransaction.CalculateTotal();
            lblTotal.Text = $"₱ {currentTransaction.TotalAmount:N2}";
            lblItemCount.Text = $"{currentTransaction.TotalItemCount} items";

            if (decimal.TryParse(txtAmountPaid.Text, out decimal amountPaid))
            {
                currentTransaction.AmountPaid = amountPaid;
                currentTransaction.CalculateTotal();
                lblChange.Text = $"₱ {currentTransaction.Change:N2}";
                lblChange.ForeColor = currentTransaction.Change < 0 ? Color.Red : Color.Green;
            }
            else
            {
                lblChange.Text = "₱ 0.00";
            }
        }

        private void txtAmountPaid_TextChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        private void btnCompleteSale_Click(object sender, EventArgs e)
        {
            if (currentTransaction.Items.Count == 0)
            {
                Toast.Show(this, "Please add items to the cart first.", Toast.ToastType.Warning);
                return;
            }

            if (!decimal.TryParse(txtAmountPaid.Text, out decimal amountPaid) || amountPaid <= 0)
            {
                Toast.Show(this, "Please enter a valid payment amount.", Toast.ToastType.Warning);
                txtAmountPaid.Focus();
                return;
            }

            currentTransaction.AmountPaid = amountPaid;
            currentTransaction.CalculateTotal();

            if (!currentTransaction.IsPaymentSufficient)
            {
                Toast.Show(this, $"Insufficient payment!\n\nTotal: ₱{currentTransaction.TotalAmount:N2}\nPaid: ₱{amountPaid:N2}\nShort: ₱{Math.Abs(currentTransaction.Change):N2}", Toast.ToastType.Warning);
                return;
            }

            DialogResult result = ConfirmDialog.Show(this, $"Complete this sale?\n\nTotal: ₱{currentTransaction.TotalAmount:N2}\nPaid: ₱{currentTransaction.AmountPaid:N2}\nChange: ₱{currentTransaction.Change:N2}", "Confirm Sale", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                try
                {
                    currentTransaction.TransactionDate = dtpTransactionDate.Value;
                    currentTransaction.CustomerName = string.IsNullOrWhiteSpace(txtCustomerName.Text)
                        ? "Walk-in Customer"
                        : txtCustomerName.Text;
                    currentTransaction.PaymentMethod = cmbPaymentMethod.SelectedItem?.ToString() ?? "Cash";
                    currentTransaction.Notes = txtNotes.Text;

                    int transactionId = dbManager.SaveSalesTransaction(currentTransaction);

                    Toast.Show(this, $"Sale completed successfully! Transaction ID: {transactionId}", Toast.ToastType.Success);

                    // Show a preview dialog and let user print from it
                    using (var preview = new ReceiptPreviewForm(GenerateReceiptText(transactionId)))
                    {
                        preview.ShowDialog(this);
                    }

                    ResetTransaction();
                    LoadAvailableItems();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error completing sale: {ex.Message}\n\nThe transaction has been rolled back.",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private string GenerateReceiptText(int transactionId)
        {
            string receipt = "=================================\n";
            receipt += "      KIDS MERCH STORE\n";
            receipt += "=================================\n";
            receipt += $"Receipt #: {transactionId}\n";
            receipt += $"Date: {currentTransaction.TransactionDate:MM/dd/yyyy HH:mm}\n";
            receipt += $"Customer: {currentTransaction.CustomerName}\n";
            receipt += "=================================\n\n";
            foreach (var item in currentTransaction.Items)
            {
                receipt += $"{item.ItemName}\n";
                receipt += $"  ({item.Size}, {item.Color})\n";
                receipt += $"  {item.Quantity} x ₱{item.UnitPrice:N2} = ₱{item.Subtotal:N2}\n\n";
            }
            receipt += "=================================\n";
            receipt += $"TOTAL:        ₱{currentTransaction.TotalAmount:N2}\n";
            receipt += $"PAYMENT:      ₱{currentTransaction.AmountPaid:N2}\n";
            receipt += $"CHANGE:       ₱{currentTransaction.Change:N2}\n";
            receipt += "=================================\n";
            receipt += $"Payment Method: {currentTransaction.PaymentMethod}\n";
            receipt += "\nThank you for your purchase!\n";
            receipt += "=================================\n";
            return receipt;
        }

        private void ResetTransaction()
        {
            currentTransaction = new SalesTransaction();
            txtCustomerName.Clear();
            txtAmountPaid.Clear();
            txtNotes.Clear();
            cmbPaymentMethod.SelectedIndex = 0;
            dtpTransactionDate.Value = DateTime.Now;
            nudQuantity.Value = 1;
            RefreshCart();
            UpdateTotals();
        }

        private void btnNewTransaction_Click(object sender, EventArgs e)
        {
            if (currentTransaction.Items.Count > 0)
            {
                DialogResult result = ConfirmDialog.Show(this, "Current transaction will be cleared. Continue?", "New Transaction", MessageBoxButtons.YesNo);
                if (result == DialogResult.No)
                    return;
            }
            ResetTransaction();
        }

        private void dgvAvailableItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnAddToCart_Click(sender, e);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string searchText = txtSearch.Text.Trim();
                if (string.IsNullOrWhiteSpace(searchText))
                {
                    LoadAvailableItems();
                    return;
                }

                string query = @"SELECT ItemID, ItemName, Category, Size, Color, Quantity, Price 
                               FROM ClothingInventory 
                               WHERE Quantity > 0 AND IsDeleted = 0
                               AND (ItemName LIKE @search OR Category LIKE @search OR Color LIKE @search OR Size LIKE @search)
                               ORDER BY ItemName";

                var parameters = new Dictionary<string, object> { { "@search", "%" + searchText + "%" } };
                DataTable dt = dbManager.ExecuteQuery(query, parameters);
                dgvAvailableItems.DataSource = dt;
                lblAvailableCount.Text = $"{dt.Rows.Count} items found";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}