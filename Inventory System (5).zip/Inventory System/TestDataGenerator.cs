using System;
using Microsoft.Data.SqlClient;
using System.Diagnostics;

namespace KidsMerch
{
    /// <summary>
    /// Debug-only utility class to generate test data for the inventory system.
    /// Methods are compiled out of non-debug builds.
    /// </summary>
    internal class TestDataGenerator
    {
        private string connectionString;

        public TestDataGenerator(string connString)
        {
            connectionString = connString;
        }

        [Conditional("DEBUG")]
        /// <summary>
        /// Generate random test data
        /// </summary>
        public void GenerateTestData(int numberOfItems = 50)
        {
            Random rand = new Random();

            string[] categories = { "T-Shirt", "Pants", "Dress", "Jacket", "Shorts", "Skirt", "Sweater", "Jeans", "Shoes", "Accessories" };
            string[] sizes = { "XS", "S", "M", "L", "XL", "XXL", "XXXL" };
            string[] colors = { "Black", "White", "Blue", "Red", "Green", "Yellow", "Gray", "Navy", "Brown", "Pink" };
            string[] suppliers = { "Fashion Distributors Inc.", "Urban Wear Co.", "Denim World", "Elegant Wear Co.", "Premium Outerwear", "Summer Styles Ltd.", "Winter Warmth Co.", "Outdoor Gear Suppliers", "Athletic Footwear Inc.", "Accessories Plus" };

            string[] itemPrefixes = { "Classic", "Modern", "Vintage", "Premium", "Designer", "Casual", "Sport", "Formal", "Trendy", "Retro" };

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    for (int i = 1; i <= numberOfItems; i++)
                    {
                        string category = categories[rand.Next(categories.Length)];
                        string prefix = itemPrefixes[rand.Next(itemPrefixes.Length)];
                        string itemName = $"{prefix} {category} #{i}";
                        string size = sizes[rand.Next(sizes.Length)];
                        string color = colors[rand.Next(colors.Length)];
                        int quantity = rand.Next(5, 100);
                        decimal price = Math.Round((decimal)(rand.NextDouble() * 150 + 10), 2);
                        string supplier = suppliers[rand.Next(suppliers.Length)];

                        string query = @"INSERT INTO ClothingInventory (ItemName, Category, Size, Color, Quantity, Price, Supplier) 
                                       VALUES (@ItemName, @Category, @Size, @Color, @Quantity, @Price, @Supplier)";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@ItemName", itemName);
                            cmd.Parameters.AddWithValue("@Category", category);
                            cmd.Parameters.AddWithValue("@Size", size);
                            cmd.Parameters.AddWithValue("@Color", color);
                            cmd.Parameters.AddWithValue("@Quantity", quantity);
                            cmd.Parameters.AddWithValue("@Price", price);
                            cmd.Parameters.AddWithValue("@Supplier", supplier);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    Console.WriteLine($"Successfully generated {numberOfItems} test items!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error generating test data: {ex.Message}");
            }
        }

        [Conditional("DEBUG")]
        /// <summary>
        /// Clear all test data
        /// </summary>
        public void ClearAllData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM ClothingInventory";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        int rowsDeleted = cmd.ExecuteNonQuery();
                        Console.WriteLine($"Deleted {rowsDeleted} items from database.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error clearing data: {ex.Message}");
            }
        }

        [Conditional("DEBUG")]
        /// <summary>
        /// Generate specific test scenarios
        /// </summary>
        public void GenerateTestScenarios()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Scenario 1: Low stock items (for testing alerts)
                    InsertItem(conn, "Low Stock T-Shirt", "T-Shirt", "M", "Red", 3, 19.99m, "Fashion Distributors Inc.");
                    InsertItem(conn, "Low Stock Jeans", "Jeans", "L", "Blue", 2, 59.99m, "Denim World");

                    // Scenario 2: High value items (for testing price filtering)
                    InsertItem(conn, "Designer Suit", "Jacket", "L", "Black", 10, 499.99m, "Premium Outerwear");
                    InsertItem(conn, "Luxury Watch", "Accessories", "M", "Silver", 5, 999.99m, "Accessories Plus");

                    // Scenario 3: High quantity items (for testing inventory)
                    InsertItem(conn, "Basic White Socks", "Accessories", "M", "White", 500, 4.99m, "Fashion Distributors Inc.");

                    // Scenario 4: Items with special characters (for testing search)
                    InsertItem(conn, "50% Off! T-Shirt", "T-Shirt", "L", "Blue", 25, 9.99m, "Urban Wear Co.");
                    InsertItem(conn, "O'Reilly's Jacket", "Jacket", "M", "Brown", 15, 89.99m, "O'Reilly Clothing");

                    Console.WriteLine("Test scenarios generated successfully!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error generating test scenarios: {ex.Message}");
            }
        }

        private void InsertItem(SqlConnection conn, string name, string category, string size, string color, int quantity, decimal price, string supplier)
        {
            string query = @"INSERT INTO ClothingInventory (ItemName, Category, Size, Color, Quantity, Price, Supplier) 
                           VALUES (@ItemName, @Category, @Size, @Color, @Quantity, @Price, @Supplier)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ItemName", name);
                cmd.Parameters.AddWithValue("@Category", category);
                cmd.Parameters.AddWithValue("@Size", size);
                cmd.Parameters.AddWithValue("@Color", color);
                cmd.Parameters.AddWithValue("@Quantity", quantity);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@Supplier", supplier);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
