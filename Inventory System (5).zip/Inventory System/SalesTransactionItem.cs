using System;

namespace KidsMerch
{
    /// <summary>
    /// Represents a single item in a sales transaction
    /// </summary>
    public class SalesTransactionItem
    {
        public int TransactionItemID { get; set; }
        public int TransactionID { get; set; }
        public int ItemID { get; set; }
        public string ItemName { get; set; }
        public string Category { get; set; }
        public string Size { get; set; }
        public string Color { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Subtotal { get; set; }

        public SalesTransactionItem()
        {
        }

        public SalesTransactionItem(ClothingItem item, int quantity)
        {
            ItemID = item.ItemID;
            ItemName = item.ItemName;
            Category = item.Category;
            Size = item.Size;
            Color = item.Color;
            Quantity = quantity;
            UnitPrice = item.Price;
            CalculateSubtotal();
        }

        /// <summary>
        /// Calculate subtotal based on quantity and unit price
        /// </summary>
        public void CalculateSubtotal()
        {
            Subtotal = Quantity * UnitPrice;
        }

        /// <summary>
        /// Get formatted price with currency
        /// </summary>
        public string FormattedUnitPrice
        {
            get { return UnitPrice.ToString("C2"); }
        }

        /// <summary>
        /// Get formatted subtotal with currency
        /// </summary>
        public string FormattedSubtotal
        {
            get { return Subtotal.ToString("C2"); }
        }

        public override string ToString()
        {
            return $"{ItemName} ({Size}, {Color}) x{Quantity} = {FormattedSubtotal}";
        }
    }
}
